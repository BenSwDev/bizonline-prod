<?php
include_once "../../bin/system.php";
include_once "../../bin/top.php";

$areaID = 0;

if('POST' == $_SERVER['REQUEST_METHOD']){
	$name = inputStr($_POST['newarea']);
	$name_eng = inputStr($_POST['newarea_eng']);
	$name_fra = inputStr($_POST['newarea_fra']);
	$mar = intval($_POST['mar']);

	$que = "SELECT `areaID` FROM `areas` WHERE `TITLE` = '".$name."'";
	$sql =  udb::single_row($que);
	if ($sql){
		$error = "Area already exists in database";
	}elseif (!$name){
		$error = "Empty area name";
	}elseif (!$mar){
		$error = "Please choose region.";
	}else {

		$id = udb::insert('areas', [
			'TITLE'   => $name,
			'main_areaID'   => $mar
		], true);

	   udb::insert('areas_text', [
			'areaID'   => $id,
			'LangID' => 1,
			'TITLE'   => $name
		], true);
		if($_POST['newarea_eng']){

		   udb::insert('areas_text', [
				'areaID'   => $id,
				'LangID' => 2,
				'TITLE'   => $_POST['newarea_eng']
			], true);
		}
		if($_POST['newarea_fra']){
			
			 udb::insert('areas_text', [
				'areaID'   => $id,
				'LangID' => 3,
				'TITLE'   => $_POST['newarea_fra']
			], true);
		
		}

		$que = "OPTIMIZE TABLE `main_areas`";
		udb::query($que);
	}
}
elseif ($d = intval($_GET['adel'])){
	$que = "UPDATE `settlements` SET settlements.areaID = 0 WHERE settlements.areaID = ".$d;
	udb::query($que);
	$que = "DELETE FROM `areas` WHERE areaID = ".$d;
	udb::query($que);
	$que = "DELETE FROM `areas_text` WHERE areaID = ".$d;
	udb::query($que);
	$que = "OPTIMIZE TABLE `areas`,`settlements`";
	udb::query($que);
}


$que="SELECT * FROM `areas` WHERE 1 ORDER BY `TITLE`";
$areas= udb::key_row($que, "areaID");


$que="SELECT `main_areaID`,`TITLE` FROM `main_areas` WHERE 1 ORDER BY `main_areaID`";
$main_areas= udb::key_row($que, "main_areaID" );

$que = "SELECT * FROM areas_text WHERE 1";
$main_areas_langs = udb::key_row($que, array("areaID","LangID"));


?>
<style type="text/css">
	input[type="checkbox"]{-webkit-appearance:checkbox;}
</style>
<div class="popGallery">
	<div class="popGalleryCont"></div>
</div>
<script type="text/javascript" src="areas.js?v=1.1"></script>
<script type="text/javascript" src="../../app/subsys.js"></script>
<div class="manageItems" id="manageItems">
    <h1>ניהול אזורים</h1>
	<form method="POST" style="margin:0px" onSubmit="return checkForm('a')">
    <table>
        <thead>
		<tr>
			<th width="30">#</th>
			<th>שם איזור</th>
			<th>שם אזור אנגלית</th>
			<th>שם אזור ברוסית</th>
			<th>איזור ראשי</th>
			<th>מוצג בהצעה אוטומטית</th>
			<th width="60">&nbsp;</th>
		</tr>
        </thead>
        <tbody>
		<tr>
			<th>חדש:</th>
			<td><input type="text" class="inptText" name="newarea" id="newarea" value=""></td>
			<td><input type="text" class="inptText" name="newarea_eng" id="newarea_eng" value=""></td>
			<td><input type="text" class="inptText" name="newarea_fra" id="newarea_ru" value=""></td>
			<td>
				<select name="mar" id="mar">
					<option value="0">בחר...</option>
					<?
					foreach($main_areas as $main){
						echo '<option value="',$main['main_areaID'],'">',$main['TITLE'],'</option>';
					}
					?>
				</select>
			</td>
			<td></td>
			<td align="center"><input type="submit" value="הוסף" class="submit"></td>
		</tr>
		<?
			$q = 0;
			foreach($areas as $aid => $arr){
				$link = ($aid == $areaID) ? 'areas.php' : 'areas.php?area='.$aid;
		?>
		<tr <?=$color?> id="tra<?=$aid?>">
			<td align="center"><?=$aid?></td>
			<td><?=$arr['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('areaID=<?=$aid?>',1,'areas_text')"></td>
			<td><?=$main_areas_langs[$aid][2]['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('areaID=<?=$aid?>',2,'areas_text')"></td>
			<td><?=$main_areas_langs[$aid][3]['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('areaID=<?=$aid?>',3,'areas_text')"></td>

			<td><?=$main_areas[$arr['main_areaID']]['TITLE']?></td>
			<td><input type="checkbox" name="autoSug" value="1" onclick="autoSugChange(this,<?=$aid?>)" <?=($arr['activeAutoSuggest']==1?"checked":"")?>></td>
			<td align="center" class="actb">
			<div onClick="tab_edit('a<?=$aid?>')"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;שנה שם</div><div>|</div><div onClick="if(confirm('You are about to delete area. Continue?')){location.href='?adel=<?=$aid?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
		</tr>
		<?  }  ?>
        </tbody>
    </table>
	</form>
</div>
<?php if($error){ ?>
<script>formAlert("red","","<?=$error?>");</script>
<?php } ?>
<?php
include_once "../../bin/footer.php";
?>


<script type="text/javascript">
	
	function showText(id,lang,table){
		$(".popGalleryCont").html('<iframe width="100%" height="100%" id="frame_'+lang+'" frameborder=0 src="/cms/moduls/locations/frameText.php?id='+id+'&lang='+lang+'&table='+table+'"></iframe><div class="tabCloserSpace" onclick="tabCloserGlobGal(\'frame_'+lang+'\')">x</div>');
		$(".popGallery").show();
		var elme = window.parent.document.getElementById("frame_"+lang);
	
		elme.style.zIndex="16";
		elme.style.position="relative";
	}

	function tabCloserGlobGal(id){
		$(".popGalleryCont").html('');
		$(".popGallery").hide();
		var elme = window.parent.document.getElementById(id);
		elme.style.zIndex="12";
		elme.style.position ="static";
	}
	function autoSugChange(elem,id){
		var status = 0;
		if($(elem).is(':checked')){
			status = 1;
		}
		$.post('ajax_autoSug.php',{id:id,status:status});
	}
</script>