<?php
include_once "../../bin/system.php";
include_once "../../bin/top.php";

$areaID = 0;
ob_start();
if($_GET['adel']){

	udb::query("DELETE FROM main_areas WHERE main_areaID=".intval($_GET['adel']));
	udb::query("DELETE FROM main_areas_text WHERE main_areaID=".intval($_GET['adel']));
	header("Refresh:0");

}

if('POST' == $_SERVER['REQUEST_METHOD']){


	$name = inputStr($_POST['newarea']);
	$que = "SELECT `main_areaID` FROM `main_areas` WHERE `TITLE` = '".$name."'";
	$sql =  udb::single_row($que);
	if ($sql){
		$error = "Area already exists in database";
	}elseif (!$name){
		$error = "Empty area name";
	}else {
		$id = udb::insert('main_areas', [
			'TITLE'   => $name
		], true);

	   udb::insert('main_areas_text', [
			'main_areaID'   => $id,
			'LangID' => 1,
			'TITLE'   => $name
		], true);
		if($_POST['newarea_eng']){

		   udb::insert('main_areas_text', [
				'main_areaID'   => $id,
				'LangID' => 2,
				'TITLE'   => $_POST['newarea_eng']
			], true);
		}
		if($_POST['newarea_fra']){
			
			 udb::insert('main_areas_text', [
				'main_areaID'   => $id,
				'LangID' => 3,
				'TITLE'   => $_POST['newarea_fra']
			], true);
		
		}

		$que = "OPTIMIZE TABLE `main_areas`";
		udb::query($que);

	}
}




$que="SELECT `main_areaID`,`TITLE` FROM `main_areas` WHERE 1 ORDER BY `main_areaID`";
$main_areas= udb::key_row($que, "main_areaID");
$que = "SELECT * FROM main_areas_text WHERE 1";
$main_areas_langs = udb::key_row($que, array("main_areaID","LangID"));


?>
<div class="popGallery">
	<div class="popGalleryCont"></div>
</div>
<script type="text/javascript" src="areas.js?v=1"></script>
<script type="text/javascript" src="../../app/subsys.js"></script>
<div class="manageItems" id="manageItems">
    <h1>ניהול אזורים ראשיים</h1>
	<form method="POST" style="margin:0px" onSubmit="return checkForm('a')">
    <table>
        <thead>
		<tr>
			<th width="30">#</th>
			<th>שם איזור ראשי</th>
			<th>שם אזור אנגלית</th>
			<th>שם אזור ברוסית</th>
			<th width="60">&nbsp;</th>
		</tr>
        </thead>
        <tbody>
		<tr>
			<th>חדש:</th>
			<td><input type="text" class="inptText" name="newarea" id="newarea" value=""></td>
			<td><input type="text" class="inptText" name="newarea_eng" id="newarea_eng" value=""></td>
			<td><input type="text" class="inptText" name="newarea_fra" id="newarea_ru" value=""></td>
			<td align="center"><input type="submit" value="הוסף" class="submit"></td>
		</tr>
		<?
			$q = 0;
			foreach($main_areas as $aid => $arr){
				
		?>
		<tr <?=$color?> id="trm<?=$aid?>">
			<td align="center"><?=$aid?></td>
			<td><?=$arr['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('main_areaID=<?=$aid?>',1,'main_areas_text')"></td>
			<td><?=$main_areas_langs[$aid][2]['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('main_areaID=<?=$aid?>',2,'main_areas_text')"></td>
			<td><?=$main_areas_langs[$aid][3]['TITLE']?><img src="/cms/images/textA.gif" border="0" onclick="showText('main_areaID=<?=$aid?>',3,'main_areas_text')"></td>
			<td align="center" class="actb">
			<div onClick="tab_edit('m<?=$aid?>')"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;שנה שם</div><div>|</div><div onClick="if(confirm('You are about to delete area. Continue?')){location.href='?adel=<?=$aid?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
		</tr>
		<?  }  ?>
        </tbody>
    </table>
	</form>
</div>
<?php if($error){ ?>
<script>formAlert("red","","<?=$error?>");</script>
<?php } ?>
<?php
include_once "../../bin/footer.php";
?>


<script type="text/javascript">
	

	function showText(id,lang,table){
		$(".popGalleryCont").html('<iframe width="100%" height="100%" id="frame_'+lang+'" frameborder=0 src="/cms/moduls/locations/frameText.php?id='+id+'&lang='+lang+'&table='+table+'"></iframe><div class="tabCloserSpace" onclick="tabCloserGlobGal(\'frame_'+lang+'\')">x</div>');
		$(".popGallery").show();
		var elme = window.parent.document.getElementById("frame_"+lang);
	
		elme.style.zIndex="16";
		elme.style.position="relative";
	}

	function tabCloserGlobGal(id){
		$(".popGalleryCont").html('');
		$(".popGallery").hide();
		var elme = window.parent.document.getElementById(id);
		elme.style.zIndex="12";
		elme.style.position ="static";
	}

</script>