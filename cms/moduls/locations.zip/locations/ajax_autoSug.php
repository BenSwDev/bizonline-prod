<?php 

	include_once "../../bin/system.php";
	  $siteData = [
            'activeAutoSuggest' => intval($_POST['status'])
		];
    udb::update('areas', $siteData, '`areaID` = '.intval($_POST['id']));

