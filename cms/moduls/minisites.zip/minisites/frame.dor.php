<?php
include_once "../../bin/system.php";
include_once "../../bin/top_frame.php";
include_once "mainTopTabs.php";
include_once "../../_globalFunction.php";

const BASE_LANG_ID = 1;

$pageID = intval($_POST['pageID'] ?? $_GET['pageID'] ?? 0);
$siteID = intval($_POST['siteID'] ?? $_GET['siteID'] ?? 0);
$siteName = $_GET['siteName'];

if ('POST' == $_SERVER['REQUEST_METHOD']){

	
    try {

		
        $data = typemap($_POST, [
            'siteName'   => ['int' => 'string'],
            'address'    => ['int' => 'string'],
            'owners'     => ['int' => 'string'],
            'phone'      => ['int' => 'string'],
            'phone2'     => ['int' => 'string'],
            '!active'    => ['int' => 'int'],
            'shortDesc'  => ['int' => ['int' => 'html']],
            'seoTitle'   => ['int' => ['int' => 'string']],
            'seoH1'      => ['int' => ['int' => 'string']],
            'seoLink'    => ['int' => ['int' => 'string']],
            'seoKwords'  => ['int' => ['int' => 'string']],
            'seoDesc'    => ['int' => ['int' => 'string']],

            'reviewWriter'    => 'int',
            'reviewStarter'    => ['int' => ['int' => 'html']],
            'reviewReport'    => ['int' => ['int' => 'html']],
            'review'    => ['int' => ['int' => 'html']],
            'reviewTitle'    => ['int' => ['int' => 'html']],
            'searchBoxSent'    => ['int' => ['int' => 'string']],
            'ownerSay'    => ['int' => ['int' => 'html']],
            'areaTrip'    => ['int' => ['int' => 'html']],
            'arriveCenter'    => ['int' => ['int' => 'html']],
            'arriveInside'    => ['int' => ['int' => 'html']],
            'reviewLocation'    => ['int' => ['int' => 'html']],
            'reviewInPlace'    => ['int' => ['int' => 'html']],
            'reviewGoodToKnow'    => ['int' => ['int' => 'html']],
            'reviewFeeling'    => ['int' => ['int' => 'html']],
            'reviewWeLiked'    => ['int' => ['int' => 'html']],
            'reviewAttentionTo'    => ['int' => ['int' => 'html']],
            'reviewHostsInfo'    => ['int' => ['int' => 'html']],

            'cancellation'    => ['int' => ['int' => 'html']],
            'orderTerms'    => ['int' => ['int' => 'html']],
            'hostInclude'    => ['int' => ['int' => 'html']],
            '!attributes'    => ['int' => 'int'],
            'breakFastMenu'    => ['int' => ['int' => 'html']],
            'areas'      => ['int'],
            'video'      => ['string'],
            'city'       => 'int',
            '!onlineOrder'   => 'int',
            'email'      => 'email',
            'password'   => 'string',
            'website'   => 'string',
            'facebook'   => 'string',
            'googlePlus' => 'string',
            'youtube1' => 'string',
            'youtube2' => 'string',
            'youtube3' => 'string',
            'gpsLat' => 'string',
            'gpsLong' => 'string',
            'checkInHour' => 'string',
            'checkOutHour' => 'string',
            'checkOutHourSat' => 'string',
            'maskyooPhone' => 'string',
            'phoneSms' => 'string',
            'sysRemarks' => 'html'
        ]);
        if (!$data['siteName'][BASE_LANG_ID])
            throw new LocalException('חייב להיות שם בעברית');

        // main site data
        $siteData = [
            'active'       => $data['active'][0],
            'settlementID' => $data['city'],
            'siteName'     => $data['siteName'][BASE_LANG_ID],
            'email'        => $data['email'],
            'password'     => password_hash($data['password'], PASSWORD_DEFAULT),
            'phone'        => $data['phone'][0],
            'phone2'       => $data['phone2'][0],
            'website'      => $data['website'],
            'facebook'     => $data['facebook'],
            'googlePlus'   => $data['googlePlus'],
            'youtube1'   => $data['youtube1'],
            'youtube2'   => $data['youtube2'],
            'youtube3'   => $data['youtube3'],
            'gpsLat'   => $data['gpsLat'],
            'gpsLong'   => $data['gpsLong'],
            'checkInHour'   => $data['checkInHour'],
            'checkOutHour'   => $data['checkOutHour'],
            'checkOutHourSat'   => $data['checkOutHourSat'],
            'reviewWriter'   => $data['reviewWriter'],
            'sysRemarks'   => $data['sysRemarks'],
            'maskyooPhone'   => $data['maskyooPhone'],
            'phoneSms'   => $data['phoneSms'],
            'onlineOrder'   => $data['onlineOrder']
        ];
		//save attributes

		$photo = pictureUpload('hostsPicture',"../../../gallery/");
		if($photo){
			$siteData["hostsPicture"] = $photo[0]['file'];
		}

        if (!$siteID){      // opening new site
            $siteID = udb::insert('sites', $siteData);
			//open new gallery folder
			udb::insert('folder', ['siteID'=>$siteID,'folderTitle'=>$data['siteName'][BASE_LANG_ID],'isMain'=>1]);

        } else {
            udb::update('sites', $siteData, '`siteID` = ' . $siteID);
        }



		$dataPrice = typemap($_POST, [

			'extraPriceAdultWeekday'   => ['int' => 'int'],
			'extraPriceAdultWeekend'   => ['int' => 'int'],
			'extraPriceKidWeekday'   => ['int' => 'int'],
			'extraPriceKidWeekend'   => ['int' => 'int']
		]);
		
		$normalP = [
			'siteID'=>$siteID,
			'periodType'	=>1,
			'extraPriceAdultWeekday' =>$dataPrice['extraPriceAdultWeekday'][1],
			'extraPriceAdultWeekend' =>$dataPrice['extraPriceAdultWeekend'][1],
			'extraPriceKidWeekday' =>$dataPrice['extraPriceKidWeekday'][1],
			'extraPriceKidWeekend' =>$dataPrice['extraPriceKidWeekend'][1]
		];
		$hotP = [
			'siteID'=>$siteID,
			'periodType'	=>2,
			'extraPriceAdultWeekday' =>$dataPrice['extraPriceAdultWeekday'][2],
			'extraPriceAdultWeekend' =>$dataPrice['extraPriceAdultWeekend'][2],
			'extraPriceKidWeekday' =>$dataPrice['extraPriceKidWeekday'][2],
			'extraPriceKidWeekend' =>$dataPrice['extraPriceKidWeekend'][2]
		];
		  udb::insert('sites_prices', $normalP,true);
		  udb::insert('sites_prices', $hotP,true);


		udb::query('DELETE FROM `sites_areas` WHERE siteID='.$siteID);
		if(count($data['areas'])){
			foreach($data['areas'] as $attr){
					
				$siteArea['siteID'] = $siteID;
				$siteArea['areaID'] = $attr;
				udb::insert('sites_areas', $siteArea);
			
			}
		}
		udb::query('DELETE FROM `sites_attributes` WHERE siteID='.$siteID);
		if(count($data['attributes'])){
			foreach($data['attributes'] as $attr){
					
				$attribute['siteID'] = $siteID;
				$attribute['attrID'] = $attr;
				udb::insert('sites_attributes', $attribute);
			
			}
		}

        // saving data per domain
        foreach(DomainList::get() as $did => $dom){
         //   if ($did > 0) {     // no need to save "default" domain, as it is already saved in main table
                // inserting/updating data in domains table
                udb::insert('sites_domains', [
                    'siteID'   => $siteID,
                    'domainID' => $did,
                    'active'   => $data['active'][$did],
                    'phone'    => $data['phone'][$did],
                    'phone2'   => $data['phone2'][$did]
                ], true);
           // }

            // saving data per domain / language
            foreach(LangList::get() as $lid => $lang){
                // inserting/updating data in domains table
                udb::insert('sites_langs', [
                    'siteID'    => $siteID,
                    'domainID'  => $did,
                    'langID'    => $lid,
                    'siteName'  => $data['siteName'][$lid],
                    'address'   => $data['address'][$lid],
                    'owners'    => $data['owners'][$lid],
                    'shortDesc' => $data['shortDesc'][$did][$lid],
                    'cancellation' => $data['cancellation'][$did][$lid],
                    'orderTerms' => $data['orderTerms'][$did][$lid],
                    'hostInclude' => $data['hostInclude'][$did][$lid],
                    'breakFastMenu' => $data['breakFastMenu'][$did][$lid],
                    'searchBoxSent' => $data['searchBoxSent'][$did][$lid],
                    'reviewTitle' => $data['reviewTitle'][$did][$lid],
                    'ownerSay' => $data['ownerSay'][$did][$lid],
                    'arriveCenter' => $data['arriveCenter'][$did][$lid],
                    'areaTrip' => $data['areaTrip'][$did][$lid],
                    'arriveInside' => $data['arriveInside'][$did][$lid],
                    'review' => $data['review'][$did][$lid],
                    'reviewReport' => $data['reviewReport'][$did][$lid],
                    'reviewStarter' => $data['reviewStarter'][$did][$lid],
                    'reviewLocation' => $data['reviewLocation'][$did][$lid],
                    'reviewInPlace' => $data['reviewInPlace'][$did][$lid],
                    'reviewGoodToKnow' => $data['reviewGoodToKnow'][$did][$lid],
                    'reviewFeeling' => $data['reviewFeeling'][$did][$lid],
                    'reviewWeLiked' => $data['reviewWeLiked'][$did][$lid],
                    'reviewAttentionTo' => $data['reviewAttentionTo'][$did][$lid],
                    'reviewHostsInfo' => $data['reviewHostsInfo'][$did][$lid]
                ], true);
            }
        };


/*        $que = ['active' => $data['active'], 'categoryID' => $data['categoryID'], 'defaultName' => $data['defaultName']];
        if ($attrID){
            udb::update('attributes', $que, '`attrID` = ' . $attrID);
        } else {
            udb::query("LOCK TABLES `attributes` WRITE");
            $que['showOrder'] = udb::single_value("SELECT IFNULL(MAX(`showOrder`) + 1, 1) FROM `attributes` WHERE `categoryID` = " . $data['categoryID']);

            $attrID = udb::insert('attributes', $que);
            udb::query("UNLOCK TABLES");
        }

        $dlist = [];
        $doms  = udb::single_column("SELECT `domainID` FROM `domains` WHERE 1", 0);
        $langs = udb::single_column("SELECT `langID` FROM `language` WHERE 1", 0);
        foreach($doms as $did){
            $dlist[] = "(" . $attrID . ", " . $did . ", " . intval($data['domActive'][$did]) . ")";

            $list = [];
            foreach($langs as $lid)
                $list[] = "(" . $attrID . ", " . $did .  ", " . $lid . ", '" . udb::escape_string($data['attrName'][$did][$lid]) . "', '" . udb::escape_string($data['attrDesc'][$did][$lid]) . "'
                    , '" . udb::escape_string($data['attrHeadTitle'][$did][$lid]) . "', '" . udb::escape_string($data['attrHeadDesc'][$did][$lid]) . "', '" . udb::escape_string($data['attrHeadKeys'][$did][$lid]) . "')";
            count($list) and udb::query("INSERT INTO `attributes_langs`(`attrID`, `domainID`, `langID`, `attrName`, `attrDesc`, `attrHeadTitle`, `attrHeadDesc`, `attrHeadKeys`)
                                            VALUES" . implode(',', $list) . " ON DUPLICATE KEY UPDATE `attrName` = VALUES(`attrName`), `attrDesc` = VALUES(`attrDesc`), `attrHeadDesc` = VALUES(`attrHeadDesc`), `attrHeadTitle` = VALUES(`attrHeadTitle`), `attrHeadKeys` = VALUES(`attrHeadKeys`)");
        }
        count($dlist) and udb::query("INSERT INTO `attributes_domains`(`attrID`, `domainID`, `active`) VALUES" . implode(',', $dlist) . " ON DUPLICATE KEY UPDATE `active` = VALUES(`active`)");*/

        //reloadParent();
    }
    catch (LocalException $e){
        // show error
    } ?>
<script>window.parent.location.reload(); window.parent.closeTab();</script>
<?php

}

$siteData = $siteDomains = $siteLangs = [];

$domainID = DomainList::active();
$langID   = LangList::active();

$areas = udb::key_value("SELECT `areaID`, `TITLE` FROM `areas` WHERE 1 ORDER BY `TITLE`");
$settlements = udb::full_list("SELECT `areaID`, `TITLE`, settlementID FROM `settlements` WHERE 1 ORDER BY `TITLE`");
$categories = udb::key_row("SELECT * FROM `attributes_categories` WHERE active=1 ORDER BY showOrder" , 'categoryID');
$attributes = udb::key_list("SELECT * FROM `attributes` WHERE active=1 ORDER BY showOrder" , 'categoryID');



if ($siteID){
    $siteData    = udb::single_row("SELECT * FROM `sites` WHERE `siteID` = " . $siteID);
    $siteDomains = udb::key_row("SELECT * FROM `sites_domains` WHERE `siteID` = " . $siteID, 'domainID');
    $siteLangs   = udb::key_row("SELECT * FROM `sites_langs` WHERE `siteID` = " . $siteID, ['domainID', 'langID']);
	$siteAttr = udb::single_column("SELECT attrID FROM `sites_attributes` WHERE `siteID`=".$siteID);
	$siteAreas = udb::single_column("SELECT areaID FROM `sites_areas` WHERE `siteID`=".$siteID);
	$siteGalleries = udb::key_list("SELECT sites_galleries.galleryID, galleries.galleryTitle, galleries.`domainID` FROM `sites_galleries`
	LEFT JOIN galleries USING (galleryID)
	WHERE sites_galleries.`siteID`=".$siteID,'domainID');
	$prices = udb::key_row('SELECT * FROM `sites_prices` WHERE `siteID`='.$siteID,"periodType");

}

	$que  = "SELECT `index` FROM `searchManager_engines` WHERE `active` = 1";
	$exEngines = udb::single_column($que);

	$que = "SELECT * FROM reviewsWriters WHERE active=1 ORDER BY showOrder";
	$reviewsWriters = udb::full_list($que);
?>
<!--  -->
<div class="editItems">
	<div class="popGallery">
		<div class="popGalleryCont"></div>
	</div>
	<div class="siteMainTitle"><?=($siteName?$siteName:"הוספת מתחם חדש")?></div>
	<?=showTopTabs()?>
	<div class="inputLblWrap langsdom">
		<div class="labelTo">דומיין</div>
        <?=DomainList::html_select()?>
	</div>
	<div class="inputLblWrap langsdom">
		<div class="labelTo">שפה</div>
        <?=LangList::html_select()?>
	</div>
	<div class="frameContent">
		<form method="post" enctype="multipart/form-data" >
			<div class="mainSectionWrapper">
				<div class="sectionName">כללי</div>
<?php
    foreach(LangList::get() as $id => $lang){
?>
		<div class="language" data-id="<?=$id?>">
			<div class="inputLblWrap">
				<div class="labelTo">שם המתחם</div>
				<input type="text" placeholder="כתובת" name="siteName" value="<?=js_safe($siteLangs[0][$id]['siteName'])?>" />
			</div>
			<div class="inputLblWrap">
				<div class="labelTo">כתובת</div>
				<input type="text" placeholder="כתובת" name="address" value="<?=js_safe($siteLangs[0][$id]['address'])?>" />
			</div>
			<div class="inputLblWrap">
				<div class="labelTo">שם בעלים</div>
				<input type="text" placeholder="שם בעלים" name="owners" value="<?=js_safe($siteLangs[0][$id]['owners'])?>" />
			</div>
		</div>
<?php
    }

    foreach(DomainList::get() as $id => $dom){
?>
		<div class="domain" data-id="<?=$id?>">
			<div class="inputLblWrap">
				<div class="labelTo">טלפון</div>
				<input type="text" placeholder="טלפון" name="phone" value="<?=js_safe($siteDomains[$id]['phone'])?>" />
			</div>
			<div class="inputLblWrap">
				<div class="labelTo">טלפון נוסף</div>
				<input type="text" placeholder="טלפון נוסף" name="phone2" value="<?=js_safe($siteDomains[$id]['phone2'])?>" />
			</div>
			<div class="inputLblWrap">
				<div class="switchTtl">מוצג</div>
				<label class="switch">
				  <input type="checkbox" name="active" value="1" <?=($siteDomains[$id]['active'] ? 'checked="checked"' : '')?> <?=($siteData['active']==1 && $id==0)?"checked":""?> />
				  <span class="slider round"></span>
				</label>
			</div>
<?php ?>
			<div class="inputLblWrap">
				<div class="labelTo">טלפון למיסוך</div>
				<input type="text" placeholder="טלפון למיסוך" name="maskyooPhone" value="<?=$siteData['maskyooPhone']?>" />
			</div>
			<div class="inputLblWrap">
				<div class="labelTo">סולולארי להודעות</div>
				<input type="text" placeholder="סולולארי להודעות" name="phoneSms" value="<?=$siteData['phoneSms']?>" />
			</div>

       <?php foreach(LangList::get() as $lid => $lang){ ?>
                    <div class="language" data-id="<?=$lid?>">
                        <div class="section txtarea big">
                            <div class="label">תיאור קצר: </div>
                            <textarea name="shortDesc" class="shortextEditor" title=""><?=$siteLangs[$id][$lid]['shortDesc']?></textarea>
                        </div>
                    </div>
		<?php } ?>
                </div>
<?php } ?>

			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">SEO</div>
				<?php foreach(DomainList::get() as $did => $dom){
						foreach(LangList::get() as $lid => $lang){ ?>
							<div class="domain" data-id="<?=$did?>">
								<div class="language" data-id="<?=$lid?>">
									<div class="inputLblWrap">
										<div class="labelTo">כותרת עמוד</div>
										<input type="text" placeholder="כותרת עמוד" name="" value="" />
									</div>
									<div class="inputLblWrap">
										<div class="labelTo">H1</div>
										<input type="text" placeholder="H1" name="H1" value="" />
									</div>
									<div class="inputLblWrap">
										<div class="labelTo">קישור</div>
										<input type="text" placeholder="קישור" name="link" value="" />
									</div>
									<div class="section txtarea">
										<div class="inptLine">
											<div class="label">מילות מפתח</div>
											<textarea name="seoKeyword"><?=outDb($page['seoKeyword'])?></textarea>
										</div>
									</div>
									<div class="section txtarea">
										<div class="inptLine">
											<div class="label">תאור דף</div>
											<textarea name="seoDesc"><?=outDb($page['seoDesc'])?></textarea>
										</div>
									</div>
								</div>
							</div>
				<?php } } ?>
			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">מיקום</div>
				<div class="inSectionWrap">
					<div class="inputLblWrap">
						<div class="labelTo">אזורים</div>
						<div class="selectAndCheck" id="areasChecks">
							<div class="choosenCheck"></div>
							<div class="checksWrrap">
								<?php
									foreach($areas as $aid => $aname)
										echo '<div><input type="checkbox" name="areas[]" value="' , $aid , '" ' , (in_array($aid, $siteAreas) ? 'checked="checked"' : '') , ' /> ' , $aname , '</div>';
								?>
							</div>
						</div>
					</div>
					<div class="inputLblWrap">
						<div class="labelTo">ישוב</div>
						<select name="city" title="ישוב">
							<option value="0">- - בחר ישוב - -</option>
							<?php foreach($settlements as $settlement){ ?>
								<option value="<?=$settlement['settlementID']?>" <?=($siteData['settlementID']==$settlement['settlementID']?" selected":"")?> data-area="<?=$settlement['areaID']?>"><?=$settlement['TITLE']?></option>
							<?php } ?>
						</select>
					</div>
					<div class="clear"></div>
					<div class="inputLblWrap">
						<div class="labelTo">GPS Lat</div>
						<input type="text" placeholder="Lat" name="gpsLat" value="<?=$siteData['gpsLat']?>" />
					</div>
					<div class="inputLblWrap">
						<div class="labelTo">GPS Long</div>
						<input type="text" placeholder="Long" name="gpsLong" value="<?=$siteData['gpsLong']?>" />
					</div>
				</div>
			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">שעות כניסה, פרטים נוספים, ותנאי ביטול</div>

				<div class="inputLblWrap">
					<div class="labelTo">שעת כניסה</div>
					<input type="time" class="timepicker" placeholder="שעת כניסה" name="checkInHour" value="<?=$siteData['checkInHour']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">שעת יציאה</div>
					<input type="time" class="timepicker" placeholder="שעת יציאה" name="checkOutHour" value="<?=$siteData['checkOutHour']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">שעת יציאה בשבת</div>
					<input type="time" class="timepicker" placeholder="שעת יציאה בשבת" name="checkOutHourSat" value="<?=$siteData['checkOutHourSat']?>" />
				</div>



<?php
    foreach(DomainList::get() as $did => $dom){
        foreach(LangList::get() as $lid => $lang){ ?>
			<div class="domain" data-id="<?=$did?>">
				<div class="language" data-id="<?=$lid?>">
					<div class="section txtarea big">
						<div class="inptLine">
							<div class="label noFloat">תנאי ביטול</div>
							<textarea class="textEditor" name="cancellation"><?=outDb($siteLangs[$did][$lid]['cancellation'])?></textarea>
						</div>
					</div>
					<div class="section txtarea big">
						<div class="inptLine">
							<div class="label noFloat">חוקי המקום</div>
							<textarea class="textEditor" name="orderTerms"><?=outDb($siteLangs[$did][$lid]['orderTerms'])?></textarea>
						</div>
					</div>
					<div class="section txtarea big">
						<div class="inptLine">
							<div class="label noFloat">כלול באירוח</div>
							<textarea class="textEditor" name="hostInclude"><?=outDb($siteLangs[$did][$lid]['hostInclude'])?></textarea>
						</div>
					</div>
					<div class="section txtarea big">
						<div class="inptLine">
							<div class="label noFloat">תפריט ארוחת בוקר</div>
							<textarea class="textEditor" name="breakFastMenu"><?=outDb($siteLangs[$did][$lid]['breakFastMenu'])?></textarea>
						</div>
					</div>
				</div>
			</div>
<?php
        }
    } ?>


			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">פרטי התחברות משתמש</div>
				<div class="inputLblWrap">
					<div class="labelTo">אימייל</div>
					<input type="text" placeholder="אימייל" name="email" value="" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">סיסמא</div>
					<input type="password" placeholder="סיסמא" name="password" value="" />
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">מדיה</div>
				<div class="inputLblWrap">
					<div class="labelTo">אתר אינטרנט</div>
					<input type="text" placeholder="אתר אינטרנט" name="website" value="<?=$siteData['website']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">פייסבוק</div>
					<input type="text" placeholder="פייסבוק" name="facebook" value="<?=$siteData['facebook']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">גוגל פלוס</div>
					<input type="text" placeholder="גוגל פלוס" name="googlePlus" value="<?=$siteData['googlePlus']?>" />
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">תמונה מייצגת</div>
				<div style="border:1px solid #ccc;display:inline-block;vertical-align:top;clear:both;">
					<div class="section">
						<div class="inptLine">
							<div class="label">תמונה  - קיץ</div>
							<input type="file" name="pictureSummery" class="inpt" value="<?=$page['pictureSummery']?>">
						</div>
					</div>
					<?php if($page['pictureSummery']){ ?>
					<div class="section">
						<div class="inptLine">
							<img src="../../gallery/<?=$page['pictureSummery']?>" style="width:100%">
						</div>
					</div>
					<?php } ?>
				</div>
				<div style="border:1px solid #ccc;display:inline-block;vertical-align:top;clear:both;">
					<div class="section">
						<div class="inptLine">
							<div class="label">תמונה - חורף</div>
							<input type="file" name="pictureWinter" class="inpt" value="<?=$page['pictureWinter']?>">
						</div>
					</div>
					<?php if($page['pictureWinter']){ ?>
					<div class="section">
						<div class="inptLine">
							<img src="../../gallery/<?=$page['pictureWinter']?>" style="width:100%">
						</div>
					</div>
					<?php } ?>
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">גלריה</div>
				<div class="manageItems">
					<div class="addButton" style="margin-top: 20px;">
					<?php foreach(DomainList::get() as $domid => $dom){ ?>
						<div class="domain" data-id="<?=$domid?>">
							<div class="tableWrap">
								<div class="rowWrap top">
									<!-- <div class="tblCell">#</div> -->
									<div class="tblCell">galleryID</div>
									<div class="tblCell">שם הגלריה</div>
									<div class="tblCell"></div>
								</div>
								<?php foreach($siteGalleries[$domid] as $gallery) { ?>
								<div class="rowWrap">
									<!-- <div class="tblCell">**</div> -->
									<div class="tblCell"><?=$gallery['galleryID']?></div>
									<div class="tblCell"><?=$gallery['galleryTitle']?></div>
									<div class="tblCell"><span onclick="galleryOpen(<?=$domid.",".$siteID.",".$gallery['galleryID']?>)"  class="editGalBtn">ערוך גלריה</span></div>
								</div>
								<?php } ?>
							</div>
							<div class="addNewBtnWrap">
								<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הוסף חדש" onclick="galleryOpen(<?=$domid.",".$siteID?>,'new')" >
							</div>
						</div>
					<?php } ?>

						<?php if($galleries){ ?>
						<!-- <input type="button" class="addNew" id="buttonOrder" onclick="orderNow(this)" value="ערוך סדר תצוגה"> -->
						<?php } ?>
					</div>
					<?php
						if($galleries){ ?>
					<table>
						<thead>
						<tr>
							<th width="30">#</th>
							<th>שם גלריה</th>
							<th>מוצג באתר</th>
							<th width="60">&nbsp;</th>
						</tr>
						</thead>
						<tbody  id="sortRow">

						<?php foreach($galleries as $row) { ?>
							<tr  id="<?=$row['GalleryID']?>">
								<td align="center"><?=$row['GalleryID']?></td>
								<td onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><?=outDb($row['GalleryTitle'])?></td>
								<td align="center"><?=($row['ifShow']?"<span style='color:green;'>כן</span>":"<span style='color:red;'>לא</span>")?></td>
								<td align="center" class="actb">
								<div onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;ערוך</div><div>|</div><div onClick="if(confirm('אתה בטוח??')){location.href='?sID=<?=$siteID?>&frame=<?=$frameID?>&gdel=<?=$row['GalleryID']?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
							</tr>
						<? } ?>
						</tbody>
					</table>
					<? } ?>
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">חוות דעת הפסגה</div>
				<div class="inputLblWrap">
					<div class="inputLblWrap">
						<div class="labelTo">כותב חוות דעת</div>
						<select name="reviewWriter">
							<option value="0">בחר כותב חוות דעת</option>
							<?php foreach($reviewsWriters as $writer) { ?>
							<option value="<?=$writer['writerID']?>" <?=($siteData['reviewWriter']==$writer['writerID'])?"selected":""?>><?=$writer['writerName']?></option>
							<?php } ?>
						</select>
					</div>
					<!-- <input type="text" placeholder="כותב חוות דעת" name="reviewWriter" value="<?=outDb($siteLangs[$did][$lid]['reviewWriter'])?>" /> -->
				</div>
				<div style="border:1px solid #ccc;display:inline-block;vertical-align:top;clear:both;">
					<div class="section">
						<div class="inptLine">
							<div class="label">תמונה של המארחים</div>
							<input type="file" name="hostsPicture" class="inpt" value="<?=$siteData['hostsPicture']?>">
						</div>
					</div>
					<?php if($siteData['hostsPicture']){ ?>
					<div class="section">
						<div class="inptLine">
							<img src="../../../gallery/<?=$siteData['hostsPicture']?>" style="width:100%">
						</div>
					</div>
					<?php } ?>
				</div>
			
			
				<?php foreach(DomainList::get() as $did => $dom){
					foreach(LangList::get() as $lid => $lang){ ?>
						<div class="domain" data-id="<?=$did?>">
							<div class="language" data-id="<?=$lid?>">

								<div class="section txtarea big">
									<div class="label">משפט בקופסת חיפוש</div>
									<textarea name="searchBoxSent"><?=outDb($siteLangs[$did][$lid]['searchBoxSent'])?></textarea>
								</div>

								<div class="section txtarea big">
									<div class="label">כותרת</div>
									<textarea name="reviewTitle" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewTitle'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">דו"ח המבקר</div>
									<textarea name="reviewReport" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewReport'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">חוות דעת</div>
									<textarea name="review" class="textEditor"><?=outDb($siteLangs[$did][$lid]['review'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">פתיח</div>
									<textarea name="reviewStarter" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewStarter'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">לוקיישן ואווירה</div>
									<textarea name="reviewLocation" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewLocation'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">מה במקום</div>
									<textarea name="reviewInPlace" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewInPlace'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">כדאי לדעת</div>
									<textarea name="reviewGoodToKnow" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewGoodToKnow'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">יצאנו בהרגשה ש</div>
									<textarea name="reviewFeeling" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewFeeling'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">על המארחים</div>
									<textarea name="reviewHostsInfo" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewHostsInfo'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">אהבנו</div>
									<textarea name="reviewWeLiked" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewWeLiked'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">שמנו לב ש</div>
									<textarea name="reviewAttentionTo" class="textEditor"><?=outDb($siteLangs[$did][$lid]['reviewAttentionTo'])?></textarea>
								</div>

							</div>
						</div>
				<?php } } ?>


			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">מאפיינים</div>
				<?php foreach($categories as $category) { ?>
					<div class="catName"><?=$category['categoryName']?></div>
					<div class="checksWrap">
						<?php foreach($attributes[$category['categoryID']] as $attribute) { ?>
						<div class="checkLabel checkIb">
							<div class="checkBoxWrap">
								<input class="checkBoxGr" type="checkbox" name="attributes[]" <?=(in_array($attribute['attrID'],$siteAttr)?"checked":"")?> value="<?=$attribute['attrID']?>" id="ch<?=$attribute['attrID']?>">
								<label for="ch<?=$attribute['attrID']?>"></label>
							</div>
							<label for="ch<?=$attribute['attrID']?>"><?=$attribute['defaultName']?></label>
						</div>
						<?php } ?>
					</div>
				<?php } ?>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">סרטוני יוטיוב</div>
				<div class="inputLblWrap">
					<div class="labelTo">סרטון 1</div>
					<input type="text" placeholder="" name="youtube1" value="<?=$siteData['youtube1']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">סרטון 2</div>
					<input type="text" placeholder="" name="youtube2" value="<?=$siteData['youtube2']?>" />
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">סרטון 2</div>
					<input type="text" placeholder="" name="youtube3" value="<?=$siteData['youtube3']?>" />
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">הגדרת ימי אמצ"ש סופ"ש</div>
				<div class="weekTbl">
					<div class="tblRow">
						<div class="tblCell">נחשב לסופ"ש</div>
						<div class="tblCell"></div>
						<div class="tblCell"></div>
						<div class="tblCell"></div>
						<div class="tblCell"></div>
						<div class="tblCell">
							<div class="checkLabel">
								<div class="checkBoxWrap">
									<input type="checkbox" name="" id="weekend5">
									<label for="weekend5"></label>
								</div>
							</div>
						</div>
						<div class="tblCell">
							<div class="checkLabel">
								<div class="checkBoxWrap">
									<input type="checkbox" name="" id="weekend6">
									<label for="weekend6"></label>
								</div>
							</div>
						</div>
						<div class="tblCell">
							<div class="checkLabel">
								<div class="checkBoxWrap">
									<input type="checkbox" name="" id="weekend7">
									<label for="weekend7"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="tblRow">
						<div class="tblCell"></div>
						<div class="tblCell">א</div>
						<div class="tblCell">ב</div>
						<div class="tblCell">ג</div>
						<div class="tblCell">ד</div>
						<div class="tblCell">ה</div>
						<div class="tblCell">ו</div>
						<div class="tblCell">ש</div>
					</div>
					<div class="tblRow">
						<div class="tblCell">מינימום לילות</div>
						<?php for($i=1;$i<=7;$i++) { ?>
						<div class="tblCell">
							<input type="number" class="inputNumber" min="1" max="7" maxlength="1" name="" id="dd<?=$i?>">
						</div>
						<?php } ?>

					</div>
					<div class="tblRow">
						<div class="tblCell">הזמנת לילה<br>ברגע האחרון</div>
						<?php for($i=1;$i<=7;$i++) { ?>
						<div class="tblCell">
							<input type="number" class="inputNumber2" maxlength="99" min="99999" max="5" name="" id="dm<?=$i?>">
						</div>
						<?php } ?>
					</div>

				</div>

			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">הזמנות</div>

				<div class="inputLblWrap">
					<div class="switchTtl">הזמנות און ליין</div>
					<label class="switch">
					  <input type="checkbox" name="onlineOrder" value="1" <?=($siteData['onlineOrder'] ? 'checked="checked"' : '')?>/>
					  <span class="slider round"></span>
					</label>
				</div>
				<div class="inputLblWrap">
					<div class="inputLblWrap">
						<div class="labelTo">Approval type</div>
						<select name="orderApproveType">
							<option value="-1">אין</option>
							<option value="0">Order after approval</option>
							<option value="1"> Immediate order</option>
						</select>
					</div>
				</div>
				<div class="inputLblWrap" id="exSection">
					<div class="inputLblWrap">
						<div class="labelTo">מערכת חיצונית :</div>
						<select name="externalEngine">
							<option value="">- - - - - - - -</option>
							<?php
								foreach($exEngines as $ev)
									echo '<option value="' , $ev , '" ' , (strcmp($ev, $site['externalEngine']) ? '' : 'selected="selected"') , '>' , $ev , '</option>';
							?>
						</select>
					</div>
				</div>
			</div>

			<div class="mainSectionWrapper">
				<div class="sectionName">הגדרות נוספות</div>
				<?php foreach(DomainList::get() as $did => $dom){
					foreach(LangList::get() as $lid => $lang){ ?>
						<div class="domain" data-id="<?=$did?>">
							<div class="language" data-id="<?=$lid?>">
								<div class="section txtarea big">
									<div class="label">המארחים מספרים</div>
									<textarea name="ownerSay" class="textEditor"><?=outDb($siteLangs[$did][$lid]['ownerSay'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">טיול רומנטי</div>
									<textarea name="areaTrip" class="textEditor"><?=outDb($siteLangs[$did][$lid]['areaTrip'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">איך להגיע מהמרכז</div>
									<textarea name="arriveCenter" class="textEditor"><?=outDb($siteLangs[$did][$lid]['arriveCenter'])?></textarea>
								</div>
								<div class="section txtarea big">
									<div class="label">איך להגיע בתוך הישוב</div>
									<textarea name="arriveInside" class="textEditor"><?=outDb($siteLangs[$did][$lid]['arriveInside'])?></textarea>
								</div>
							</div>
						</div>
				<?php } } ?>
						<div class="section txtarea big">
							<div class="label">הערה לעורך האתר</div>
							<textarea name="sysRemarks" class=""><?=outDb($siteData['sysRemarks'])?></textarea>
						</div>
			</div>
			<div class="mainSectionWrapper">
				<div class="sectionName">הגדרות מחירי תוספת - ברירת מחדל</div>
				<div class="tablWrapper doInline">
					<div class="tablTttl">הגדרת מחיר תוספת ילד/מבוגר תקופה רגילה</div>
					<div class="baseTbl prices">
						<div class="tblRow">
							<div class="tblCell"></div>
							<div class="tblCell ttl">אמצ"ש</div>
							<div class="tblCell ttl">סופ"ש</div>
						</div>
						<div class="tblRow">
							<div class="tblCell">
								<div class="top">תוספת מבוגר</div>
							</div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekday[1]" value="<?=$prices[1]['extraPriceAdultWeekday']?>"></div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekend[1]" value="<?=$prices[1]['extraPriceAdultWeekend']?>"></div>
						</div>
						<div class="tblRow">
							<div class="tblCell">
								<div class="top">תוספת ילד</div>
							</div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekday[1]" value="<?=$prices[1]['extraPriceKidWeekday']?>"></div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekend[1]" value="<?=$prices[1]['extraPriceKidWeekend']?>"></div>
						</div>
					</div>
				</div>
				<div class="tablWrapper doInline">
					<div class="tablTttl">הגדרת מחיר תוספת ילד/מבוגר תקופה חמה</div>
					<div class="baseTbl prices">
						<div class="tblRow">
							<div class="tblCell"></div>
							<div class="tblCell ttl">אמצ"ש</div>
							<div class="tblCell ttl">סופ"ש</div>
						</div>
						<div class="tblRow">
							<div class="tblCell">
								<div class="top">תוספת מבוגר</div>
							</div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekday[2]" value="<?=$prices[2]['extraPriceAdultWeekday']?>"></div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekend[2]" value="<?=$prices[2]['extraPriceAdultWeekend']?>"></div>
						</div>
						<div class="tblRow">
							<div class="tblCell">
								<div class="top">תוספת ילד</div>
							</div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekday[2]" value="<?=$prices[2]['extraPriceKidWeekday']?>"></div>
							<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekend[2]" value="<?=$prices[2]['extraPriceKidWeekend']?>"></div>
						</div>
					</div>
				</div>
			</div>
			<input type="submit" value="שמור" class="submit">
		</form>
	</div>
</div>

<script src="../../app/tinymce/tinymce.min.js"></script>
<script>

/*
function CustomCheckBox(cont, opt){
	var self = this;
		this.values = [];
		this.cont = $(cont);
		this.settings = $.extend({
			openClass: 'open',
			activeClass: 'active',
			childs: '.checkLabel',
			label: '.choosenCheck',
			fieldName: this.cont.attr('id') || 'checkBox'
		}, (opt || {}));

		this.input = $('<input type="hidden" name="'+ this.settings.fieldName +'" value="" />');


		this.cont.on('click', this.settings.label, function(){
			self.cont.toggleClass(self.settings.openClass);
		})
		.append(this.input)
		.find(this.settings.childs).on('click', function(){
			$(this).toggleClass(self.settings.activeClass);
			self._toggleSelected($(this).data('value'));
			self.updateDom();
		}).filter('.'+this.settings.activeClass).each(function(){
			self._toggleSelected($(this).data('value'));
		});
		
		self.updateDom();
}
$.extend(CustomCheckBox.prototype, {
	_toggleSelected: function(value){
		var index = this.values.indexOf(value);

		if(index > -1){
			this.values.splice(index, 1);
		}else{
			this.values.push(value);
		}

		this.values = this.values.sort();

	},
	updateDom: function(){

		var self = this;

		this.cont.find(this.settings.label).text($.map(this.values, function(index){
			return self.cont.find(self.settings.childs+'[data-value='+index+']').text();
		}).join(', '));

		this.input.val(this.values.join());
	}
});

var AreasCCB = new CustomCheckBox('#areasChecks');
*/






$(function(){
	
	$('.mainSectionWrapper').click(function(){
		var editors = $(this).find('textarea.textEditor:not([aria-hidden=true])');

		if(editors.length){
			editors.each(function(){
				tinymce.init({
				  target: this,
				  height: 500,
				 plugins: [
					"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak",
					"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
					"table contextmenu directionality emoticons textcolor paste  textcolor colorpicker textpattern"
				  ],
				  fontsize_formats: '8px 10px 12px 14px 16px 18px 20px 22px 24px 30px 36px',
				  toolbar1: "newdocument | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
				  toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
				  toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking pagebreak restoredraft"
				});
			});
		}
	})
/*		tinymce.init({
		  selector: 'textarea.textEditor' ,
		  height: 500,
		 plugins: [
			"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
			"table contextmenu directionality emoticons textcolor paste  textcolor colorpicker textpattern"
		  ],
		  fontsize_formats: '8px 10px 12px 14px 16px 18px 20px 22px 24px 30px 36px',
		  toolbar1: "newdocument | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
		  toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
		  toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking pagebreak restoredraft"

		}); */
	});



    var inputQuantity = [];
    $(function() {
      $(".inputNumber").each(function(i) {
        inputQuantity[i]=this.defaultValue;
         $(this).data("idx",i); // save this field's index to access later
      });
      $(".inputNumber").on("keyup", function (e) {
        var $field = $(this),
            val=this.value,
            $thisIndex=parseInt($field.data("idx"),10); // retrieve the index
//        window.console && console.log($field.is(":invalid"));
          //  $field.is(":invalid") is for Safari, it must be the last to not error in IE8
        if (this.validity && this.validity.badInput || isNaN(val) || $field.is(":invalid") ) {
            this.value = inputQuantity[$thisIndex];
            return;
        }
        if (val.length > Number($field.attr("maxlength"))) {
          val=val.slice(0, 5);
          $field.val(val);
        }
        inputQuantity[$thisIndex]=val;
      });
    });


	/*facilities save to one input
	var hidenInputFac = $("input[name='facilities']");
	var facilArr = [];
	if(hidenInputFac.val()){
		facilArr = [hidenInputFac.val()];
	}
	$('.checkBoxGr').change(function(){
	
		if($(this).is(':checked')){
			facilArr.push($(this).attr('id'));
		}
		else{
			facilArr.splice($.inArray($(this).attr('id')), 1 );
		}
		hidenInputFac.val(facilArr);
	});*/


	function galleryOpen(domainID,siteID,galleryID){
		$(".popGalleryCont").html('<iframe width="100%" height="100%" id="frame_'+domainID+'_'+siteID+'_'+galleryID+'" frameborder=0 src="/cms/moduls/minisites/galleryGlobal.php?domainID='+domainID+'&siteID='+siteID+'&gID='+galleryID+'"></iframe><div class="tabCloserSpace" onclick="tabCloserGlobGal(\'frame_'+siteID+'\')">x</div>');
		$(".popGallery").show();
		var elme = window.parent.document.getElementById("frame_"+siteID);
	
		elme.style.zIndex="16";
		elme.style.position="relative";
	}

	function tabCloserGlobGal(id){
		$(".popGalleryCont").html('');
		$(".popGallery").hide();
		var elme = window.parent.document.getElementById(id);
		elme.style.zIndex="12";
		elme.style.position ="static";
	}

/*

	$(".general .lngtab").click(function(){
		$(".general .lngtab").removeClass("active");
		$(this).addClass("active");

		var ptID = $(this).data("langid");
		$(".frm").css("display","none");

		$("#langTab"+ptID).css("display","block");
	});
*/

$(function(){
    $.each({domain: <?=$domainID?>, language: <?=$langID?>}, function(cl, v){
        $('.' + cl).hide().each(function(){
            var id = $(this).data('id');
            $(this).find('input, select, textarea').each(function(){
                this.name = this.name + '[' + id + ']';
            });
        }).filter('[data-id="' + v + '"]').show();

        $('.' + cl + 'Selector').on('change', function(){
            $('.' + cl, $(this).data('cont')).hide().filter('[data-id="' + this.value + '"]').show();
        });
    });

    var sel = $('select', '#exSection');
    sel.on('change', function(){
        $('#exSection2').remove();

        if (this.value != ''){
            $.getJSON('js_exEngine.php', {act:'list', sid:<?=$siteID?>, id:this.value}, function(res){
                if (res.error)
                    return alert(res.error);
                else
                    $('#exSection').after('<div class="section" id="exSection2"><div class="inptLine"><div class="label">מזהה חיצוני :</div>' + res.html + '</div></div>');
            });
        }
    }).trigger('change');


	function MultiCcLabel(){
		$('#areasChecks .choosenCheck').text($('#areasChecks input:checked').map(function(){
			return $(this.parentNode).text();
		}).get().join(', '));
	};

	MultiCcLabel();

	$('#areasChecks .choosenCheck').click(function(){
		$(this.parentNode).toggleClass('open');
	}).parent().find('input').off('click').click(MultiCcLabel);

});
</script>
