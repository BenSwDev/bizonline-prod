

		<div class="calendar <?=$_POST['dir']?>">
			<div class="tableRow date">
				<div class="tblCell"></div>
				<div class="tblCell">
					<div class="fLine">30/08</div>
					<div class="sLine">ראשון</div>
				</div>
				<div class="tblCell">
					<div class="fLine">31/08</div>
					<div class="sLine">שני</div>
				</div>
				<div class="tblCell">
					<div class="fLine">01/09</div>
					<div class="sLine">שלישי</div>
				</div>
				<div class="tblCell">
					<div class="fLine">02/09</div>
					<div class="sLine">רביעי</div>
				</div>
				<div class="tblCell">
					<div class="fLine">03/09</div>
					<div class="sLine">חמישי</div>
					<div class="specialDate" style="width:200%">ראש השנה</div>
				</div>
				<div class="tblCell">
					<div class="fLine">04/09</div>
					<div class="sLine">שישי</div>
				</div>
				<div class="tblCell">
					<div class="fLine">05/09</div>
					<div class="sLine">שבת</div>
				</div>
				<div class="rArrowWeek"><i class="fa fa-angle-right"></i></div><div class="lArrowWeek"><i class="fa fa-angle-left"></i></div>
			</div>
			<div class="tableRow sum">
				<div class="tblCell">כל היחידות</div>
				<div class="mobTtl">כל היחידות</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
				<div class="tblCell">
					<div class="free">
						<div class="num">4</div>
						<div class="label">פנוי</div>
					</div>
					<div class="occ">
						<div class="num">2</div>
						<div class="label">תפוס</div>
					</div>
				</div>
			</div>
			<div class="divScroll">
				<div class="tableRow site">
					<div class="tblCell" onclick="showAll(1)">
						<div class="topCellSite">
							<div class="siteTDetails">
								היחידה הצפונית
							</div>
						</div>
					</div>
					<div class="mobTtl">היחידה הצפונית <i class="fa fa-times"></i> <span>3</span></div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
				</div>
				<div class="tableRow siteOcc" data-siteNum="1">
					<div class="tblCell"><div class="siteNum">1</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occNames" style="width:calc(200% - 5px)">יהודית ואבי ועוד שם ארוך מאוד</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
				</div>
				<div class="tableRow siteOcc" data-siteNum="1">
					<div class="tblCell"><div class="siteNum">2</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occ">תפוס</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occ">תפוס</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
				</div>
				<div class="tableRow site">
					<div class="tblCell" onclick="showAll(2)">
						<div class="topCellSite">
							<div class="siteTDetails">
								היחידה הדרומית
							</div>
						</div>
					</div>
					<div class="mobTtl">היחידה הדרומית <i class="fa fa-times"></i> <span>3</span></div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
					<div class="tblCell">
						<div class="topCellSite">
							<div class="siteTDetails">
								<div class="unitDet">
									<div class="num">2</div>
									<div class="lbl">פנוי</div>
									<div class="freeArr"><i class="fa fa-angle-right"></i></div>
								</div>
								<div class="unitDet">
									<div class="num">1</div>
									<div class="lbl">תפוס</div>
									<div class="occArr"><i class="fa fa-angle-left"></i></div>
								</div>
								<div class="sep"></div>
								<div class="all">3</div>
							</div>
						</div>
					</div>
				</div>
				<div class="tableRow siteOcc" data-siteNum="2">
					<div class="tblCell"><div class="siteNum">1</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occNames" style="width:calc(200% - 5px)">יהודית ואבי ועוד שם ארוך מאוד</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
				</div>
				<div class="tableRow siteOcc" data-siteNum="2">
					<div class="tblCell"><div class="siteNum">2</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occ">תפוס</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="occ">תפוס</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
					<div class="tblCell"><div class="event">&nbsp;</div><div class="free">פנוי</div></div>
				</div>
			</div>
		</div>