<?php
include_once "../../../bin/system.php";
include_once "../../../bin/top_frame.php";
include_once "../mainTopTabs.php";
include_once "../../../_globalFunction.php";

if($_GET['srdel']==1 && $_GET['spaceID']!=""){

	udb::query("DELETE FROM `spaces` WHERE spaceID=".intval($_GET['spaceID']));
	udb::query("DELETE FROM `spaces_langs` WHERE spaceID=".intval($_GET['spaceID']));
	udb::query("DELETE FROM `spaces_accessories` WHERE spaceID=".intval($_GET['spaceID']));
	udb::query("DELETE FROM `spaces_accessories_langs` WHERE spaceID=".intval($_GET['spaceID']));

?>

<script>window.parent.location.reload(); window.parent.closeTab();</script>
<?php
}

const BASE_LANG_ID = 1;

$siteID = intval($_GET['siteID']);
$roomID = intval($_POST['roomID'] ?? $_GET['roomID'] ?? 0);
$siteName = $_GET['siteName'];




if ('POST' == $_SERVER['REQUEST_METHOD']){



    try {
        $data = typemap($_POST, [
            'roomTitle'   => ['int' => 'string'],
            'roomNote'   => ['int' => 'string'],
            '!active'    => ['int' => 'int'],
            '!recommend'    => ['int' => 'int'],
            'roomDesc'  => ['int' => ['int' => 'html']],
            'roomType'   => 'int',
            'roomCount'   => 'int',
            'roomOrPage'   => 'int',
            'maxKids'   => 'int',
            'maxAdults'   => 'int',
            'maxGuests'   => 'int',
            'basisGuests'   => 'int',
            'couplesOrFamily'   => 'int',
            'roomSize'   => 'string',
            'showSpaceAccessories'   => 'int'
        ]);

        // main room data
        $siteData = [
            'active'    => $data['active'][0],
            'recommend'    => $data['recommend'][0],
            'siteID'    => $siteID,
            'roomName'  => $data['roomTitle'][BASE_LANG_ID],
			'roomType'  => $data['roomType'],
			'roomCount' => $data['roomCount'],
			'roomOrPage' => $data['roomOrPage'],
			'maxKids'		=>$data['maxKids'],
			'maxAdults'		=>$data['maxAdults'],
			'maxGuests'		=>$data['maxGuests'],
			'basisGuests'		=>$data['basisGuests'],
			'roomSize' => $data['roomSize'],
			'showSpaceAccessories' => $data['showSpaceAccessories'],
			'couplesOrFamily' => $data['couplesOrFamily']

        ];
        if (!$roomID){      // opening new room
            $roomID = udb::insert('rooms', $siteData);
        } else {
            udb::update('rooms', $siteData, '`roomId` = ' . $roomID);
		
			$dataPrice = typemap($_POST, [
				'weekday'    => ['int' => ['int' => 'int']],
				'weekend'    => ['int' => ['int' => 'int']],
				'extraPriceAdultWeekday'   => ['int' => 'int'],
				'extraPriceAdultWeekend'   => ['int' => 'int'],
				'extraPriceKidWeekday'   => ['int' => 'int'],
				'extraPriceKidWeekend'   => ['int' => 'int']
			]);
			
			$normalP = [
				'roomID'=>$roomID,
				'periodType'	=>1,
				'weekday1'		=>$dataPrice['weekday'][1][1],
				'weekday2'		=>$dataPrice['weekday'][2][1],
				'weekday3'		=>$dataPrice['weekday'][3][1],
				'weekend1'		=>$dataPrice['weekend'][1][1],
				'weekend2'		=>$dataPrice['weekend'][2][1],
				'weekend3'		=>$dataPrice['weekend'][3][1],
				'extraPriceAdultWeekday' =>$dataPrice['extraPriceAdultWeekday'][1],
				'extraPriceAdultWeekend' =>$dataPrice['extraPriceAdultWeekend'][1],
				'extraPriceKidWeekday' =>$dataPrice['extraPriceKidWeekday'][1],
				'extraPriceKidWeekend' =>$dataPrice['extraPriceKidWeekend'][1]
			];
			$hotP = [
				'roomID'=>$roomID,
				'periodType'	=>2,
				'weekday1'		=>$dataPrice['weekday'][1][2],
				'weekday2'		=>$dataPrice['weekday'][2][2],
				'weekday3'		=>$dataPrice['weekday'][3][2],
				'weekend1'		=>$dataPrice['weekend'][1][2],
				'weekend2'		=>$dataPrice['weekend'][2][2],
				'weekend3'		=>$dataPrice['weekend'][3][2],
				'extraPriceAdultWeekday' =>$dataPrice['extraPriceAdultWeekday'][2],
				'extraPriceAdultWeekend' =>$dataPrice['extraPriceAdultWeekend'][2],
				'extraPriceKidWeekday' =>$dataPrice['extraPriceKidWeekday'][2],
				'extraPriceKidWeekend' =>$dataPrice['extraPriceKidWeekend'][2]
			];
			  udb::insert('rooms_prices', $normalP,true);
			  udb::insert('rooms_prices', $hotP,true);

        }

        // saving data per domain
        foreach(DomainList::get() as $did => $dom){
            if ($did > 0) {     // no need to save "default" domain, as it is already saved in main table
                // inserting/updating data in domains table
                udb::insert('rooms_domains', [
                    'roomID'   => $roomID,
                    'domainID' => $did,
					'active'   => $data['active'][$did],
					'recommend'   => $data['recommend'][$did]
                 
                ], true);
            }

            // saving data per domain / language
            foreach(LangList::get() as $lid => $lang){
                // inserting/updating data in domains table
                udb::insert('rooms_langs', [
                    'roomID'    => $roomID,
                    'domainID'    => $did,
                    'langID'    => $lid,
                    'roomName' => $data['roomTitle'][$lid],
                    'roomNote' => $data['roomNote'][$lid],
                    'roomDesc' => $data['roomDesc'][$did][$lid]
                ], true);
            }
        };

    }
    catch (LocalException $e){
        // show error
    } ?>
<script>window.parent.location.reload(); window.parent.closeTab();</script>
<?php

}



$roomTypes = udb::full_list("SELECT * FROM `roomTypes` WHERE 1");

$roomData = $roomDomains = $roomLangs = [];

$domainID = DomainList::active();
$langID   = LangList::active();

$areas = udb::key_value("SELECT `areaID`, `TITLE` FROM `areas` WHERE 1 ORDER BY `TITLE`");



if ($roomID){
    $roomData    = udb::single_row("SELECT * FROM `rooms` WHERE `roomID` = " . $roomID);
    $roomDomains = udb::key_row("SELECT * FROM `rooms_domains` WHERE `roomID` = " . $roomID, 'domainID');
    $roomLangs   = udb::key_row("SELECT * FROM `rooms_langs` WHERE `roomID` = " . $roomID, ['domainID', 'langID']);
	$spaces = udb::full_list("SELECT spaceID,spaceName,spaceType FROM `spaces` WHERE roomID=".$roomID);
	$prices = udb::key_row('SELECT * FROM `rooms_prices` WHERE `roomID`='.$roomID,"periodType");
	if($spaces){
		$spaceType = udb::key_row("SELECT * FROM spaces_type WHERE 1" , 'id');
	}
	$roomsGalleries = udb::key_list("SELECT rooms_galleries.galleryID, galleries.galleryTitle, galleries.`domainID` FROM `rooms_galleries`
	LEFT JOIN galleries USING (galleryID)
	WHERE rooms_galleries.`roomID`=".$roomID,'domainID');
}

?>



<div class="editItems">
	<div class="popGallery">
		<div class="popGalleryCont"></div>
	</div>
	<div class="frameContent">
		<div class="siteMainTitle"><?=$siteName?></div>
		<div class="roomChoosePage" <?=$roomData['roomOrPage']?"style='visibility: hidden;'":""?> >
			<div class="labelTo">חדר/דף</div>
			<select name="page" id="selectFrame">
				<option value="1" <?=($roomData['roomOrPage']==1?"selected":"")?>>חדר</option>
				<option value="2" <?=($roomData['roomOrPage']==2?"selected":"")?>>דף</option>
			</select>
		</div>
		<div class="inputLblWrap langsdom">
			<div class="labelTo">דומיין</div>
			<?=DomainList::html_select()?>
		</div>
		<div class="inputLblWrap langsdom">
			<div class="labelTo">שפה</div>
			<?=LangList::html_select()?>
		</div>
		<div id="room" class="frameChoose" style="display: block;">
			<form action="" method="post">
			<input type="hidden" name="roomOrPage" value="1">
		<?php 
		foreach(DomainList::get() as $did => $dom){ ?>
			<div class="domain" data-id="<?=$did?>">
				<div class="inputLblWrap">
					<div class="switchTtl">מוצג</div>
					<label class="switch">
					  <input type="checkbox" name="active" value="1" <?=($roomData['active']==1 && $did==0)?"checked":""?> <?=($roomDomains[$did]['active'] ? 'checked="checked"' : '')?> />
					  <span class="slider round"></span>
					</label>
				</div>

				<div class="inputLblWrap">
					<div class="switchTtl">יחידה מומלצת</div>
					<label class="switch">
					  <input type="checkbox" name="recommend" value="1" <?=($roomData['recommend']==1)?"checked":""?> <?=($roomDomains[$did]['recommend'] ? 'checked="checked"' : '')?> />
					  <span class="slider round"></span>
					</label>
				</div>

			</div>
		<?php } ?>
		<?php foreach(LangList::get() as $lid => $lang){ ?>
			<div class="language" data-id="<?=$lid?>">
				<div class="inputLblWrap">
					<div class="labelTo">שם היחידה</div>
					<input type="text" placeholder="שם היחידה" name="roomTitle" value="<?=$roomLangs[0][$lid]['roomName']?>" />
				</div>
			</div>
			<div class="language" data-id="<?=$lid?>">
				<div class="inputLblWrap">
					<div class="labelTo">הערות ליחידה</div>
					<input type="text" placeholder="הערות ליחידה" name="roomNote" value="<?=$roomLangs[0][$lid]['roomNote']?>" />
				</div>
			</div>
		<?php } ?>
		<div class="inputLblWrap">
			<div class="labelTo">סוג החדר</div>
			<select name="roomType">
			<?php foreach($roomTypes as $type) { ?>
				<option value="<?=$type['id']?>" <?=($roomData['roomType']==$type['id']?"selected":"")?> ><?=$type['roomType']?></option>
			<?php } ?>
			</select>
		</div>
		<div class="inputLblWrap">
			<div class="labelTo">כמות מבנים מסוג זה</div>
			<select name="roomCount">
			<?php for($i=1;$i<11;$i++) { ?>
				<option value="<?=$i?>"  <?=($roomData['roomCount']==$i?"selected":"")?>><?=$i?></option>
			<?php } ?>
			</select>
		</div>

		<div class="inputLblWrap">
			<div class="labelTo">גודל היחידה</div>
			<input type="text" placeholder="גודל היחידה" name="roomSize" value="<?=$roomData['roomSize']?>" />
		</div>
		<div class="inputLblWrap">
			<div class="labelTo">מתאים לזוגות/משפחות</div>
			<select name="couplesOrFamily">
				<option value="0" <?=($roomData['couplesOrFamily']==0?"selected":"")?>>---</option>
				<option value="1" <?=($roomData['couplesOrFamily']==1?"selected":"")?>>זוגות בלבד</option>
				<option value="2" <?=($roomData['couplesOrFamily']==2?"selected":"")?>>זוגות ומשפחות</option>
			</select>
		</div>


			<div  style="clear:both;"></div>
<?php
            if ($external['externalEngine'] && $external['externalID'])
			{
                include_once __DIR__ . "/../classes/class.SearchManager.php";

                if ($external['manual'])
                    $exField = '<input type="text" value="' . str_replace("'", '&#039;', outDb($room['externalRoomID'])) . '" name="exID" class="inpt" />';
                else {
                    try {
                        $exField = array('<select name="exID" style="width:186px"><option value="">- - - - - - - - - - - - -</option>');
                        foreach(SearchManager::get_room_list($siteID) as $exRid => $exRoom)
                            $exField[] = '<option value="' . $exRid . '" ' . (($exRid == $room['externalRoomID']) ? 'selected="selected"' : '') . '>' . $exRoom . '</option>';

                        $exField = implode('', $exField) . '</select>';
                    } catch (Exception $e){
                        $exField = '<input type="text" value="' . str_replace("'", '&#039;', outDb($room['externalRoomID'])) . '" name="exID" class="inpt" />';
                    }
                }
?>

			<div class="inputLblWrap">
				<div class="labelTo">מזהה חיצוני: </div>
					<?=$exField?>
				</div>
            <div  style="clear:both;"></div>
<?php 
			unset($exField); 
		} ?>

<?php 
			foreach(DomainList::get() as $did => $dom){
				foreach(LangList::get() as $lid => $lang){ ?>
				<div class="domain" data-id="<?=$did?>">
					<div class="language" data-id="<?=$lid?>">
						<div class="section txtarea big">
							<div class="label">תאור החדר</div>
							<textarea name="roomDesc" class="textEditor"><?=$roomLangs[$did][$lid]['roomDesc']?></textarea>
						</div>
					</div>
				</div>
<?php } } ?>
				<div class="clear"></div>
				<?php if($roomID) { ?>	
				<div class="mainSectionWrapper">
					<div class="popSpace">
						<div class="popSpaceCont"></div>
					</div>
					<div class="sectionName">הגדרת חללים ליחידה</div>
					<div class="addNew space" onclick="addSpacePop(<?=$_GET['roomID']?>,<?=$_GET['siteID']?>,0)">הוסף חלל</div>
					<div class="tablWrapper">
						<div class="baseTbl">
							<div class="tblRow top" >
								<div class="tblCell ttl">שם החלל</div>
								<div class="tblCell ttl">סוג החלל</div>
								<div class="tblCell ttl">&nbsp;&nbsp;</div>
							</div>
							<?php foreach($spaces as $space) { ?>
							<div class="tblRow" style="cursor:pointer">
								<div class="tblCell" onclick="addSpacePop(<?=$_GET['roomID']?>,<?=$_GET['siteID']?>,<?=$space['spaceID']?>)"><?=$space['spaceName']?></div>
								<div class="tblCell" onclick="addSpacePop(<?=$_GET['roomID']?>,<?=$_GET['siteID']?>,<?=$space['spaceID']?>)">
								<?=$spaceType[$space['spaceType']]['spaceName']?></div>
								<div class="tblCell" onclick="if(confirm('האם אתה בטוח רוצה למחוק את החלל?')){location.href='/cms/moduls/minisites/rooms/popRoom.php?roomID=<?=$roomID?>&siteID=<?=$siteID?>&spaceID=<?=$space['spaceID']?>&srdel=1'}"><i class="fa fa-trash-o" aria-hidden="true"></i> מחיקה</div>
							</div>
							<?php } ?>
						</div>
					</div>
					
					<div class="checkLabel">
						<label for="showSpaceAccessories">הצג אבזורים לחללים</label>
						<div class="checkBoxWrap">
							<input type="checkbox" name="showSpaceAccessories" id="showSpaceAccessories" value="1" <?=(($roomData['showSpaceAccessories']) ? 'checked="checked"' : '')?> title="" />
							<label for="showSpaceAccessories"></label>
						</div>
					</div>

				</div>
				<div class="mainSectionWrapper">
					<div class="sectionName">גלריה</div>
					<div class="manageItems">
						<div class="addButton" style="margin-top: 20px;">
							<?php foreach(DomainList::get() as $domid => $dom){ ?>
								<div class="domain" data-id="<?=$domid?>">
									<div class="tableWrap">
										<div class="rowWrap top">
											<!-- <div class="tblCell">#</div> -->
											<div class="tblCell">ID</div>
											<div class="tblCell">שם הגלריה</div>
											<div class="tblCell"></div>
										</div>

										<?php 
										if($roomsGalleries[$domid]){
										foreach($roomsGalleries[$domid] as $gallery) { ?>
										<div class="rowWrap">
											<!-- <div class="tblCell">**</div> -->
											<div class="tblCell"><?=$gallery['galleryID']?></div>
											<div class="tblCell"><?=$gallery['galleryTitle']?></div>
											<div class="tblCell"><span onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID.",".$roomData['galleryID']?>)"  class="editGalBtn">ערוך גלריה</span></div>
										</div>
										<?php } } ?>
									</div>
									<div class="addNewBtnWrap">
										<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הוסף חדש" onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID?>,'new')" >
									</div>

									<?php /* if(!$roomData['galleryID']){ ?>
										<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הוסף חדש" onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID?>,'new')" >
									<?php } else { ?>
										<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הצג תמונות" onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID.",".$roomData['galleryID']?>)" >
									<?php }  */?>


								</div>
							<?php } ?>
						</div>
						<?php 
							if($galleries){ ?>
						<table>
							<thead>
							<tr>
								<th width="30">#</th>
								<th>שם גלריה</th>
								<th>מוצג באתר</th>
								<th width="60">&nbsp;</th>
							</tr>
							</thead>
							<tbody  id="sortRow">

							<?php foreach($galleries as $row) { ?>
								<tr  id="<?=$row['GalleryID']?>">
									<td align="center"><?=$row['GalleryID']?></td>
									<td onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><?=outDb($row['GalleryTitle'])?></td>			
									<td align="center"><?=($row['ifShow']?"<span style='color:green;'>כן</span>":"<span style='color:red;'>לא</span>")?></td>
									<td align="center" class="actb">
									<div onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;ערוך</div><div>|</div><div onClick="if(confirm('אתה בטוח??')){location.href='?sID=<?=$siteID?>&frame=<?=$frameID?>&gdel=<?=$row['GalleryID']?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
								</tr>
							<? } ?>
							</tbody>
						</table>
						<? } ?>
					</div>
				</div>
				<div class="mainSectionWrapper">
					<div class="sectionName">הגדרות תפוסה ומחירים</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת כמות אורחים לחדר</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">כמות</div>

							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">מקסימום</div>
									<div class="bot">אורחים</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="maxGuests" value="<?=$roomData['maxGuests']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">מקסימום</div>
									<div class="bot">מבוגרים</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="maxAdults" value="<?=$roomData['maxAdults']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">מקסימום</div>
									<div class="bot">ילדים</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="maxKids" value="<?=$roomData['maxKids']?>"></div>
							</div>
						</div>
					</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת הרכב למחיר בסיס</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">כמות</div>

							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">מקסימום</div>
									<div class="bot">אורחים</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="basisGuests" value="<?=$roomData['basisGuests']?>"></div>
							</div>
						</div>
					</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת מחיר בסיס אמצ"ש סופ"ש תקופה רגילה</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">אמצ"ש</div>
								<div class="tblCell ttl">סופ"ש</div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">לילה אחד</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="weekday[1][1]" value="<?=$prices[1]['weekday1']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="weekend[1][1]" value="<?=$prices[1]['weekend1']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">2 לילות</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="weekday[2][1]" value="<?=$prices[1]['weekday2']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="weekend[2][1]" value="<?=$prices[1]['weekend2']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">3 לילות +</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell" ><input type="number" min="0" name="weekday[3][1]" value="<?=$prices[1]['weekday3']?>"></div>
								<div class="tblCell" ><input type="number" min="0" name="weekend[3][1]" value="<?=$prices[1]['weekend3']?>"></div>
							</div>
						</div>
					</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת מחיר בסיס אמצ"ש סופ"ש תקופה חמה</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">אמצ"ש</div>
								<div class="tblCell ttl">סופ"ש</div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">לילה אחד</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="weekday[1][2]" value="<?=$prices[2]['weekday1']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="weekend[1][2]" value="<?=$prices[2]['weekend1']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">2 לילות</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="weekday[2][2]" value="<?=$prices[2]['weekday2']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="weekend[2][2]" value="<?=$prices[2]['weekend2']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">3 לילות +</div>
									<div class="bot">מחיר לילה</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="weekday[3][2]" value="<?=$prices[2]['weekday3']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="weekend[3][2]" value="<?=$prices[2]['weekend3']?>"></div>
							</div>
						</div>
					</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת מחיר תוספת ילד/מבוגר תקופה רגילה</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">אמצ"ש</div>
								<div class="tblCell ttl">סופ"ש</div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">תוספת מבוגר</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekday[1]" value="<?=$prices[1]['extraPriceAdultWeekday']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekend[1]" value="<?=$prices[1]['extraPriceAdultWeekend']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">תוספת ילד</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekday[1]" value="<?=$prices[1]['extraPriceKidWeekday']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekend[1]" value="<?=$prices[1]['extraPriceKidWeekend']?>"></div>
							</div>
						</div>
					</div>
					<div class="tablWrapper doInline">
						<div class="tablTttl">הגדרת מחיר תוספת ילד/מבוגר תקופה חמה</div>
						<div class="baseTbl prices">
							<div class="tblRow">
								<div class="tblCell"></div>
								<div class="tblCell ttl">אמצ"ש</div>
								<div class="tblCell ttl">סופ"ש</div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">תוספת מבוגר</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekday[2]" value="<?=$prices[2]['extraPriceAdultWeekday']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceAdultWeekend[2]" value="<?=$prices[2]['extraPriceAdultWeekend']?>"></div>
							</div>
							<div class="tblRow">
								<div class="tblCell">
									<div class="top">תוספת ילד</div>
								</div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekday[2]" value="<?=$prices[2]['extraPriceKidWeekday']?>"></div>
								<div class="tblCell"><input type="number" min="0" name="extraPriceKidWeekend[2]" value="<?=$prices[2]['extraPriceKidWeekend']?>"></div>
							</div>
						</div>
					</div>
				</div>
				<?php } ?>
				<input type="submit" value="שמור" class="submit">
			</form>	
		</div>
		<div id="page" class="frameChoose">
			<form action="" method="post">
				<input type="hidden" name="roomOrPage" value="2">
				<?php 
				foreach(DomainList::get() as $did => $dom){ ?>
					<div class="domain" data-id="<?=$did?>">
						<div class="inputLblWrap">
							<div class="switchTtl">מוצג</div>
							<label class="switch">
							  <input type="checkbox" name="active" value="1" <?=($roomData['active']==1 && $did==0)?"checked":""?> <?=($roomDomains[$did]['active'] ? 'checked="checked"' : '')?> />
							  <span class="slider round"></span>
							</label>
						</div>
					</div>
				<?php } ?>
				<?php 
					foreach(LangList::get() as $lid => $lang){ ?>
						<div class="language" data-id="<?=$lid?>">
							<div class="inputLblWrap">
								<div class="labelTo">כותרת עמוד</div>
								<input type="text" placeholder="כותרת עמוד" value="<?=$roomLangs[0][$lid]['roomName']?>" name="roomTitle" />
							</div>
						</div>
				<?php  } ?>
				<?php 
					foreach(DomainList::get() as $did => $dom){
						foreach(LangList::get() as $lid => $lang){ ?>
						<div class="domain" data-id="<?=$did?>">
							<div class="language" data-id="<?=$lid?>">
								<div class="section txtarea big">
									<div class="label">תיאור קצר</div>
									<textarea name="roomDesc" class="textEditor"><?=$roomLangs[$did][$lid]['roomDesc']?></textarea>
								</div>
							</div>
						</div>
				<?php } } ?>

				<div class="clear"></div>
				<div class="mainSectionWrapper">
					<div class="sectionName">גלריה</div>
					<div class="manageItems">
						<div class="addButton" style="margin-top: 20px;">
							<?php foreach(DomainList::get() as $domid => $dom){ ?>
								<div class="domain" data-id="<?=$domid?>">
									<?php if(!$siteData['galleryID']){ ?>
										<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הוסף חדש" onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID?>,'new')" >
									<?php } else { ?>
										<input type="button" class="addNew" id="addNewAcc<?=$domid?>" value="הצג תמונות" onclick="galleryOpen(<?=$domid.",".$siteID.",".$roomID.",".$siteData['galleryID']?>)" >
									<?php } ?>
								</div>
							<?php } ?>
						</div>
						<?php 
							if($galleries){ ?>
						<table>
							<thead>
							<tr>
								<th width="30">#</th>
								<th>שם גלריה</th>
								<th>מוצג באתר</th>
								<th width="60">&nbsp;</th>
							</tr>
							</thead>
							<tbody  id="sortRow">

							<?php foreach($galleries as $row) { ?>
								<tr  id="<?=$row['GalleryID']?>">
									<td align="center"><?=$row['GalleryID']?></td>
									<td onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><?=outDb($row['GalleryTitle'])?></td>			
									<td align="center"><?=($row['ifShow']?"<span style='color:green;'>כן</span>":"<span style='color:red;'>לא</span>")?></td>
									<td align="center" class="actb">
									<div onclick="window.location.href='/cms/sites/gallery.php?frame=<?=$frameID?>&sID=<?=$siteID?>&gID=<?=$row['GalleryID']?>'"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;ערוך</div><div>|</div><div onClick="if(confirm('אתה בטוח??')){location.href='?sID=<?=$siteID?>&frame=<?=$frameID?>&gdel=<?=$row['GalleryID']?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
								</tr>
							<? } ?>
							</tbody>
						</table>
						<? } ?>
					</div>
				</div>
				<input type="submit" value="שמור" class="submit">
			</form>		
		</div>
	</div>
</div>


<script src="../../../app/tinymce/tinymce.min.js"></script>
<script>


	function galleryOpen(domainID,siteID,roomID,galleryID){
		$(".popGalleryCont").html('<iframe width="100%" height="100%" id="frame_'+domainID+'_'+roomID+'_'+galleryID+'" frameborder=0 src="/cms/moduls/minisites/galleryGlobal.php?domainID='+domainID+'&siteID='+siteID+'&roomID='+roomID+'&gID='+galleryID+'"></iframe><div class="tabCloserSpace" onclick="tabCloserGlobGal(\'frame_'+siteID+'_'+roomID+'\')">x</div>');
		$(".popGallery").show();
		var elme = window.parent.document.getElementById("frame_"+siteID+"_"+roomID);
	
		elme.style.zIndex="16";
		elme.style.position="relative";
	}


	function tabCloserGlobGal(id){
		$(".popGalleryCont").html('');
		$(".popGallery").hide();
		var elme = window.parent.document.getElementById(id);
		elme.style.zIndex="12";
		elme.style.position ="static";
	}


	tinymce.init({
	  selector: 'textarea.textEditor' ,
	  height: 300,  
	 plugins: [
		"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak",
		"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
		"table contextmenu directionality emoticons template textcolor paste  textcolor colorpicker textpattern"
	  ],
	  fontsize_formats: '8px 10px 12px 14px 16px 18px 20px 22px 24px 30px 36px',
	  toolbar1: "newdocument | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
	  toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
	  toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking template pagebreak restoredraft"

	});

	function addSpacePop(roomID,siteID,spaceID){

		$(".popSpaceCont").html('<iframe width="100%" height="100%" id="frame_'+siteID+'_'+roomID+'_'+spaceID+'" frameborder=0 src="/cms/moduls/minisites/rooms/space_pop.php?roomID='+roomID+'&siteID='+siteID+'&spaceID='+spaceID+'"></iframe><div class="tabCloserSpace" onclick="tabCloserSpace(\'frame_'+siteID+'_'+roomID+'\')">x</div>');
		$(".popSpace").show();
		var elme = window.parent.document.getElementById("frame_"+siteID+"_"+roomID);
		elme.style.zIndex="14";
		elme.style.position="relative";
	}

	function tabCloserSpace(id){
		$(".popSpaceCont").html('');
		$(".popSpace").hide();
		var elme = window.parent.document.getElementById(id);
		elme.style.zIndex="12";
		elme.style.position ="static";
	}


	$(function(){
    $.each({domain: <?=$domainID?>, language: <?=$langID?>}, function(cl, v){
        $('.' + cl).hide().each(function(){
            var id = $(this).data('id');
            $(this).find('input, select, textarea').each(function(){
                this.name = this.name + '[' + id + ']';
            });
        }).filter('[data-id="' + v + '"]').show();

        $('.' + cl + 'Selector').on('change', function(){
            $('.' + cl, $(this).data('cont')).hide().filter('[data-id="' + this.value + '"]').show();
        });

		$('#selectFrame').on('change', function() {

		  switch(this.value){
			case "0":$('.frameChoose').hide() ;break;
			case "1":$('.frameChoose').hide();$('#room').show();break;
			case "2":$('.frameChoose').hide();$('#page').show();break;
		  
		  }
		}).trigger('change');

    });


});
</script>