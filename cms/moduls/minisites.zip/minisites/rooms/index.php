<?php
include_once "../../../bin/system.php";
include_once "../../../bin/top_frame.php";
include_once "../mainTopTabs.php";
include_once "../../../_globalFunction.php";


$siteID=intval($_GET['siteID']);
$frameID=intval($_GET['frame']);
$siteName = $_GET['siteName'];


$pages = udb::full_list("SELECT * FROM `rooms` WHERE `siteID`=".$siteID." ORDER BY `ShowOrder`");
$roomType=udb::key_row("SELECT * FROM `roomTypes` WHERE 1","id");

?>


<div class="popRoom">
	<div class="popRoomContent"></div>
</div>
<div class="editItems">
	<div class="siteMainTitle"><?=$siteName?></div>
	<?=showTopTabs(0)?>
	<div class="manageItems" id="manageItems">
		<h1>ניהול חדרים</h1>
		<div style="margin-top: 20px;">
			<input type="button" class="addNew" id="addNewAcc" value="הוסף חדר/דף" onclick="openPopRoom(0, <?=$siteID?>)">
			<?php if($pages){ ?>
			<input type="button" class="addNew" id="buttonOrder" onclick="orderNow(this)" value="ערוך סדר תצוגה">
			<?php } ?>
		</div>
		<table>
			<thead>
			<tr>
				<th>#</th>
				<th>שם החדר</th>
				<th>סוג החדר</th>
				<th>מוצג</th>
				<th></th>
			</tr>
			</thead>
			<tbody id="sortRow">
				<?php 
				if($pages){
				foreach($pages as $key => $page){ ?>
				<tr id="<?=$page['roomID']?>">
					<td><?=$page['roomID']?></td>
					<td onclick="openPopRoom(<?=$page['roomID']?>,<?=$siteID?>)"><?=$page['roomName']?></td>
					<td onclick="openPopRoom(<?=$page['roomID']?>,<?=$siteID?>)"><?=$page['roomType']?$roomType[$page['roomType']]['roomType']:"דף"?></td>
					<td><?=($page['active']?"<span style='color:green;'>כן</span>":"<span style='color:red;'>לא</span>")?></td>
					<td><div onclick="if(confirm('האם אתה בטוח רוצה למחוק את החדר?')){location.href='?sID=<?=$siteID?>&amp;frame=&amp;rdel=<?=$page['roomID']?>';}" class="delete"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;מחק</div></td>
				</tr>
				<?php }
				} ?>
			</tbody>
		</table>
	</div>
</div>
<input type="hidden" id="orderResult" name="orderResult" value="">
<script type="text/javascript">

function openPopRoom(roomID, siteID){
	$(".popRoomContent").html('<iframe id="frame_'+siteID+'_'+roomID+'" frameborder=0 src="/cms/moduls/minisites/rooms/popRoom.php?roomID='+roomID+'&siteID='+siteID+'"></iframe><div class="tabCloser" onclick="closeTab(\'frame_'+siteID+'_'+roomID+'\')">x</div>');
	$(".popRoom").show();
	window.parent.parent.$('.tabCloser').hide();

}

function closeTab(id){
	$(".popRoomContent").html('');
	$(".popRoom").hide();
	window.parent.parent.$('.tabCloser').show();
}


function orderNow(is){
	$("#addNewAcc").hide();
	$(is).val("שמור סדר תצוגה");
	$(is).attr("onclick", "saveOrder()");
	$("#sortRow tr").attr("onclick", "");
	$("#sortRow").sortable({
		stop: function(){
			$("#orderResult").val($("#sortRow").sortable('toArray'));
		}
	});
	$("#orderResult").val($("#sortRow").sortable('toArray'));
}

function saveOrder(){
	var ids = $("#orderResult").val();
	$.ajax({
		url: 'js_order_pages.php',
		type: 'POST',
		data: {ids:ids},
		async: false,
		success: function (myData) {
			window.location.reload();
		}
	});
}
</script>