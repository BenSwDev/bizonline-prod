<?php
include_once "../../../bin/system.php";
include_once "../../../bin/top_frame.php";
include_once "../mainTopTabs.php";
include_once "../../../_globalFunction.php";
?>



<div class="editItems">
	<div class="siteMainTitle">שם הצימר</div>
	<?=showTopTabs(0)?>
	
</div>