<?php
include_once "../../../bin/system.php";
include_once "../../../bin/top_frame.php";
include_once "../../../_globalFunction.php";




const BASE_LANG_ID = 1;

$reviewID = intval($_GET['pageID']);
$siteID = intval($_POST['siteID'] ?? $_GET['siteID'] ?? 0);
$siteName = $_GET['siteName'];


if ('POST' == $_SERVER['REQUEST_METHOD']){

    try {

        $data = typemap($_POST, [
            'title'   => 'string',
            '!ifShow'    => 'int',
			'general'   => 'int',
			'clean'       => 'int',
			'maintenance'    => 'int',
			'facPrice'       => 'int',
			'relation'       => 'int',
			'privacy'        => 'int',
			'refreshment'    => 'int',
			'breakfast'      => 'int',
			'hostingDate'    => 'string',
			'text'			 => 'string',
			'ownComment'	 => 'string'
        ]);

        // main reviews data
        $siteData = [
            'ifShow'	=> $data['ifShow'],
            'siteID'    => $siteID,
            'title'		=> $data['title'],
            'text'		=> $data['text'],
			'general'   => $data['general'],
			'clean'		=> $data['clean'],
			'maintenance' => $data['maintenance'],
			'facPrice'  => $data['facPrice'],
			'relation'  => $data['relation'],
			'privacy'	=> $data['privacy'],
			'refreshment' => $data['refreshment'],
			'breakfast' => $data['breakfast'],
			'day'	    => DateTime::createFromFormat("d/m/Y", $data['hostingDate'])->format("Y-m-d"),
			'ownComment' => $data['ownComment'],
			'ownDate' => date("Y-m-d")
			//save domainID
			//save langID

        ];
        if (!$reviewID){      // opening new reviews
            $reviews = udb::insert('reviews', $siteData);
        } else {
            udb::update('reviews', $siteData, '`reviewID` = ' . $reviewID);
        }

		/*
		// saving data per domain / language
		foreach(LangList::get() as $lid => $lang){
			// inserting/updating data in domains table
			udb::insert('bonus_langs', [
				'id'    => $bonusID,
				'langID'    => $lid,
				'bonusName' => $data['bonusName'][$lid]
			], true);
		}*/
  

    }
    catch (LocalException $e){
        // show error
    } ?>
<script>window.parent.location.reload(); window.parent.closeTab();</script>
<?php

}

$reviewData = $reviewLangs = [];
$domainID = DomainList::active();
$langID   = LangList::active();

if ($reviewID){
    $reviewData    = udb::single_row("SELECT * FROM `reviews` WHERE `reviewID` = " . $reviewID);
   // $reviewLangs   = udb::key_row("SELECT * FROM `bonus_langs` WHERE `id` = " . $reviewID, ['langID']);
}


?>

<style type="text/css">
	.sectionWrap .selectWrap{width: 22%;}
	.inputLblWrap{margin: 1%;}
</style>

<div class="editItems">
	<div class="frameContent">
		<div class="siteMainTitle"><?=$siteName?></div>
		<form action="" method="post">
			<div class="inputLblWrap">
				<div class="labelTo">כותרת</div>
				<input type="text" placeholder="כותרת" value="<?=js_safe($reviewData['title'])?>" name="title" />
			</div>
			<div class="inputLblWrap">
				<div class="switchTtl">מוצג</div>
				<label class="switch">
				  <input type="checkbox" name="ifShow" value="1" <?=($reviewData['ifShow']==1)?"checked":""?> <?=($reviewID==0)?"checked":""?>/>
				  <span class="slider round"></span>
				</label>
			</div>
			<div class="titleSec">דירוג</div>
			<div class="sectionWrap">
				<div class="selectWrap">
					<div class="selectLbl">שביעות רצון כללית</div>
					<select name="general">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['general']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['general']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['general']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['general']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['general']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">נקיון</div>
					<select name="clean">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['clean']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['clean']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['clean']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['clean']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['clean']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">תחזוקה</div>
					<select name="maintenance">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['maintenance']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['maintenance']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['maintenance']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['maintenance']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['maintenance']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">אבזור ביחס למחיר</div>
					<select name="facPrice">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['facPrice']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['facPrice']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['facPrice']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['facPrice']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['facPrice']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">יחס המארחים</div>
					<select name="relation">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['relation']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['relation']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['relation']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['relation']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['relation']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">רמת פרטיות</div>
					<select name="privacy">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['privacy']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['privacy']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['privacy']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['privacy']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['privacy']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">כיבוד ופינוקים</div>
					<select name="refreshment">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['refreshment']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['refreshment']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['refreshment']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['refreshment']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['refreshment']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="selectWrap">
					<div class="selectLbl">ארוחת בוקר</div>
					<select name="breakfast">
						<option value="0">-</option>
						<option value="1" <?=($reviewData['breakfast']==1?'selected':'')?>>גרוע</option>
						<option value="2" <?=($reviewData['breakfast']==2?'selected':'')?>>סביר</option>
						<option value="3" <?=($reviewData['breakfast']==3?'selected':'')?>>טוב</option>
						<option value="4" <?=($reviewData['breakfast']==4?'selected':'')?>>טוב מאוד</option>
						<option value="5" <?=($reviewData['breakfast']==5?'selected':'')?>>מצויין</option>
					</select>
				</div>
				<div class="inputLblWrap">
					<div class="labelTo">תאריך האירוח</div>
					<input type="text" value="<?=($reviewData['day']?date("d/m/Y", strtotime($reviewData['day'])):date("d/m/Y"))?>" name="hostingDate" class="datePick" />
				</div>
				<div class="sectionWrap">
					<div class="section txtarea big">
						<div class="label">חוות דעת</div>
						<textarea name="text" class=""><?=$reviewData['text']?></textarea>
					</div>
				</div>
			</div>

			<?php if($reviewID) { ?>
			<div class="titleSec">תגובת המארח</div>
				<div class="sectionWrap">
					<div class="section txtarea big">
						<div class="label">תגובה</div>
						<textarea name="ownComment" class="textEditor"><?=$reviewData['ownComment']?></textarea>
					</div>
				</div>
			<?php } ?>
			<div class="clear"></div>
			<input type="submit" value="שמור" class="submit">
		</form>	
	</div>
</div>



<script src="../../../app/tinymce/tinymce.min.js"></script>
<script>


	$(function(){

	tinymce.init({
	  selector: 'textarea.textEditor' ,
	  height: 300,  
	 plugins: [
		"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak",
		"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
		"table contextmenu directionality emoticons template textcolor paste  textcolor colorpicker textpattern"
	  ],
	  fontsize_formats: '8px 10px 12px 14px 16px 18px 20px 22px 24px 30px 36px',
	  toolbar1: "newdocument | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
	  toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
	  toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking template pagebreak restoredraft"

	});


    $.each({domain: <?=$domainID?>, language: <?=$langID?>}, function(cl, v){
        $('.' + cl).hide().each(function(){
            var id = $(this).data('id');
            $(this).find('input, select, textarea').each(function(){
                this.name = this.name + '[' + id + ']';
            });
        }).filter('[data-id="' + v + '"]').show();

        $('.' + cl + 'Selector').on('change', function(){
            $('.' + cl, $(this).data('cont')).hide().filter('[data-id="' + this.value + '"]').show();
        });
    });


	$(".datePick").datepicker({
		format:"dd/mm/yyyy",
		changeMonth:true
	});
});
</script>