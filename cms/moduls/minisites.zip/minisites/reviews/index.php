<?php
include_once "../../../bin/system.php";
include_once "../../../bin/top_frame.php";
include_once "../mainTopTabs.php";
include_once "../../../_globalFunction.php";






$reviewID=intval($_GET['reviewID']);
$siteID=intval($_GET['siteID']);
$frameID=intval($_GET['frame']);
$siteName = $_GET['siteName'];

/*

if('POST' == $_SERVER['REQUEST_METHOD']) { 


	$cp=Array();
	$cp['vactype'] = intval($_POST['vactype']);
	$cp['newRate'] = intval($_POST['newRate']);
	$cp['com_title'] = inputStr($_POST['com_title']);
	$cp['com_name'] = inputStr($_POST['com_name']);
	$cp['com_text'] = inputStr($_POST['com_text']);
	$cp['com_mail'] = inputStr($_POST['com_mail']);
	$cp['com_phone'] = inputStr($_POST['com_phone']);
	$cp['responseUser'] = inputStr($_POST['responseUser']);
	$cp["ifShow"] = intval($_POST['ifShow'])?"1":"0";
	$cp["orderID"] = intval($_POST['orderID'])?intval($_POST['orderID']):0;
	$cp["siteID"] = $siteID;

	$date=explode("/", $_POST['dateHost']);
	$date=$date[2]."-".$date[1]."-".$date[0];
	$cp["dateHost"] = $date;



	if($reviewID){
		udb::update("Comments", $cp, "reviewID =".$reviewID);
	} else {
		$cp["add_date"] = date("Y-m-d");
		$reviewID = udb::insert("Comments", $cp);
	}

	if(isset($_POST['lang'])){
		foreach($_POST['lang'] as $lng=>$val){
			$cpLang = Array();
			$cpLang['com_title'] = $_POST['com_title_lang'][$lng];
			$cpLang['com_name'] = $_POST['com_name_lang'][$lng];
			$cpLang['com_text'] = $_POST['com_text_lang'][$lng];
			$cpLang['LangID'] = $lng;
			$cpLang['commentID'] = $commentID;
			$cpLang['PortalID'] = $_POST['PortalID'][$lng];
			$que="SELECT commentID, com_name FROM Comments_text WHERE commentID=".$commentID." AND LangID=".$lng." AND PortalID=".$_POST['PortalID'][$lng];
			$checkLang=udb::single_row($que);
			if($checkLang){
				udb::update("Comments_text", $cpLang, "commentID=".$commentID." AND LangID=".$lng." AND PortalID=".$_POST['PortalID'][$lng]);
			} else {
				udb::insert("Comments_text", $cpLang);
			}
		}
	}

	?>
	<script>window.location.href='/cms/moduls/minisites/reviews/index.php?frame=<?=$frameID?>&sID=<?=$siteID?>'</script>
	<?php
	exit;

}

*/


if (intval($_GET['delPage']))
{
	$cdel = intval($_GET['delPage']);
	
	$que = "DELETE FROM `reviews` WHERE `reviewID` = ".$cdel;
	udb::query($que);
	
	$que = "OPTIMIZE TABLE `reviews`";
	udb::query($que);
}




$que = "SELECT * FROM `reviews` WHERE `siteID` = ".$siteID." ORDER BY `day` DESC";
$comments= udb::full_list($que);


?>



<div class="popRoom"><div class="popRoomContent"></div></div>
<div class="editItems">
	<div class="siteMainTitle"><?=$siteName?></div>
	<?=showTopTabs(0)?>
		<div class="manageItems">
			<div class="addButton" style="margin-top:10px">
				<input type="button" class="addNew" value="הוסף חדש" onclick="openPop(0,<?=$siteID?>)">
			</div>
			<table border=0 style="border-collapse:collapse" align="center" cellpadding=5 cellspacing=1>
				<tr>
					<th>#</th>
					<th>כותרת</th>
					<th>דעה</th>
					<th>תאריך הוספה</th>
					<th>מוצג</th>
					<th>מחק</th>
				</tr>
				<tbody>
			<?php if($comments){
			$i = 1;
			foreach($comments as $tID => $row) {  ?>
				<tr id="com_<?=$row['reviewID']?>">
					<td align="center" onclick="openPop(<?=$row['reviewID']?>,<?=$siteID?>)"><?=($i++)?></td>
					<td align="center" onclick="openPop(<?=$row['reviewID']?>,<?=$siteID?>)"><?=$row['title']?></td>
					<td align="center" onclick="openPop(<?=$row['reviewID']?>,<?=$siteID?>)" style="font-size:13px;text-align:right;"><?=($row['text'])?></td>
					<td align="center" onclick="openPop(<?=$row['reviewID']?>,<?=$siteID?>)"><?=date("d.m.Y", strtotime($row['day']))?></td>
					<td align="center" id="commentStatus_<?=$row['reviewID']?>"><?=($row['ifShow'] ? '<span style="color:green">כן</span>' : '<span style="color:red">לא</span>')?></td>
					<td align="center" onclick="if(confirm('בטוח רוצה למחוק?')){window.location.href='/cms/moduls/minisites/reviews/index.php?tab=6&siteName=<?=$siteName?>&siteID=<?=$siteID?>&delPage=<?=$row['reviewID']?>' } ">מחק</td>

				</tr>
			<?php }
			} ?>
				</tbody>
			</table>
		</div>

	
</div>


<style>
	.manageItems table > tbody > tr > th:nth-child(1){width:40px;}
	.manageItems table > tbody > tr > th:nth-child(2){width:130px;}
	.manageItems table > tbody > tr > th:nth-child(3){width:130px;}
	.manageItems table > tbody > tr > th:nth-child(4){width:150px;}
	.manageItems table > tbody > tr > th:nth-child(5){width:130px;}
	.manageItems table > tbody > tr > th:nth-child(6){width:50px;}
	.manageItems table > tbody > tr > th:nth-child(7){width:60px;}

</style>



<script type="text/javascript">

	function openPop(pageID,siteID){
		$(".popRoomContent").html('<iframe id="frame_'+pageID+'" frameborder=0 src="/cms/moduls/minisites/reviews/frame.php?pageID='+pageID+'&siteID='+siteID+'&tab=1"></iframe><div class="tabCloser" onclick="closeTab(\'frame_'+pageID+'\')">x</div>');
		$(".popRoom").show();
		window.parent.parent.$('.tabCloser').hide();
	}
	function closeTab(){
		$(".popRoomContent").html('');
		$(".popRoom").hide();
		window.parent.parent.$('.tabCloser').show();
	}



</script>