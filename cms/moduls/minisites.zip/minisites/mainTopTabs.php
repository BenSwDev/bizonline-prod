


<?php function showTopTabs() { ?>
	<div class="siteMainTabs">
		<div class="miniTabs">
			<div class="tab<?=($_GET['tab']==1?" active":"")?>"  onclick="window.location.href='/cms/moduls/minisites/frame.dor.php?siteID=<?=$_GET['siteID']?>&tab=1&siteName=<?=$_GET['siteName']?>'"><p>המתחם</p></div>
			<?php if($_GET['siteID']!=0){ ?>
			<!-- להוסיף תנאי לאחר חיבור המערכת לא להציג טבים אלו רק אחרי יצירת צימר -->
			<div class="tab<?=($_GET['tab']==2?" active":"")?>"  onclick="window.location.href='/cms/moduls/minisites/rooms/index.php?siteID=<?=$_GET['siteID']?>&tab=2&siteName=<?=$_GET['siteName']?>'"><p>החדרים</p></div>
			<div class="tab<?=($_GET['tab']==3?" active":"")?>" onclick="window.location.href='/cms/moduls/minisites/prices/index.php?siteID=<?=$_GET['siteID']?>&tab=3&innerTab=1&siteName=<?=$_GET['siteName']?>'"><p>תמחור</p></div>
			<div class="tab<?=($_GET['tab']==4?" active":"")?>" onclick="window.location.href='/cms/moduls/minisites/occupation/index.php?siteID=<?=$_GET['siteID']?>&tab=4&siteName=<?=$_GET['siteName']?>'"><p>תפוסה</p></div>
			<div class="tab<?=($_GET['tab']==5?" active":"")?>" onclick="window.location.href='/cms/moduls/minisites/orders/index.php?siteID=<?=$_GET['siteID']?>&tab=5&siteName=<?=$_GET['siteName']?>'"><p>הזמנות</p></div>
			<div class="tab<?=($_GET['tab']==6?" active":"")?>" onclick="window.location.href='/cms/moduls/minisites/reviews/index.php?siteID=<?=$_GET['siteID']?>&tab=6&siteName=<?=$_GET['siteName']?>'"><p>חוות דעת</p></div>
			<div class="tab<?=($_GET['tab']==7?" active":"")?>" onclick="window.location.href='/cms/moduls/minisites/galleries/gallery.php?siteID=<?=$_GET['siteID']?>&tab=7&siteName=<?=$_GET['siteName']?>'"><p>גלריות - בנק</p></div>
			<?php } ?>
		</div>
	</div>
<?php } ?>
	
	
	


