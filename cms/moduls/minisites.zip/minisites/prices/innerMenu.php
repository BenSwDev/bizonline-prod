<?php 


$siteID=intval($_GET['siteID']);
$siteName = $_GET['siteName'];
function innerMenu(){ ?>

<div class="innerMenu">
	<div class="tabMenu<?=($_GET['innerTab']==1?" active":"")?>"  onclick="window.location.href='/cms/moduls/minisites/prices/index.php?siteID=<?=$_GET['siteID']?>&tab=3&innerTab=1&siteName=<?=$_GET['siteName']?>'">תוספות</div>
	<div class="tabMenu<?=($_GET['innerTab']==2?" active":"")?> " onclick="window.location.href='/cms/moduls/minisites/prices/index.php?siteID=<?=$_GET['siteID']?>&tab=3&innerTab=2&siteName=<?=$_GET['siteName']?>'">הטבות</div>
	<div class="tabMenu<?=($_GET['innerTab']==3?" active":"")?>"  onclick="window.location.href='/cms/moduls/minisites/prices/index.php?siteID=<?=$_GET['siteID']?>&tab=3&innerTab=3&siteName=<?=$_GET['siteName']?>'">חבילות</div>
</div>
	

<? } ?>