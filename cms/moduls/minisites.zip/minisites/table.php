<?php
include_once "../../bin/system.php";
include_once "../../bin/top.php";

if($_GET['free'] || $_GET['writer'] || $_GET['minisiteType'] || $_GET['domID']){
	$que = "SELECT * FROM `sites` WHERE `siteName` LIKE '%".$_GET['free']."%'";
	$sites = udb::full_list($que);

}else{

	$sites = udb::full_list("SELECT * FROM `sites` WHERE 1");
}


$roomTypes = udb::full_list("SELECT * FROM `roomTypes` WHERE 1");


?>

<div class="pagePop"><div class="pagePopCont"></div></div>
<div class="manageItems" id="manageItems">
    <h1>ניהול צימרים</h1>
	<div style="margin-top: 20px;">
		<input type="button" class="addNew" id="addNewAcc" value="הוסף חדש" onclick="openPop(0, 0)">
	</div>
	<div class="searchCms">
		<form method="GET">
			<input type="text" name="free" placeholder="מלל חופשי">
			<select name="writer">
				<option value="0">כותב חוות דעת</option>
				<option value="1"></option>
			</select>
			<select name="minisiteType">
				<option value="0" >סוג</option>
			<?php foreach($roomTypes as $type) { ?>
				<option value="<?=$type['id']?>" ><?=$type['roomType']?></option>
			<?php } ?>
			</select>
			<?=DomainList::html_select()?>
			</select>
			<a href="http://www.hapisga.c-ssd.com/cms/moduls/minisites/table.php">נקה חיפוש</a>
			<input type="submit" value="חפש">	
		</form>
	</div>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>שם המקום</th>
			<th>בעלים</th>
			<th>טלפון</th>
            <th>דוא"ל</th>
			<th width="40">מוצג</th>
        </tr>
        </thead>
        <tbody id="sortRow">
<?php
    if (count($sites)){
        foreach($sites as $site){
?>
            <tr id="<?=$site['siteID']?>">
                <td><?=$site['siteID']?></td>
                <td onclick="openPop(<?=$site['siteID']?>,'<?=$site['siteName']?>')"><?=$site['siteName']?></td>
                <td onclick="openPop(<?=$site['siteID']?>,'<?=$site['siteName']?>')"><?=outDb($site['owners'])?></td>
                <td onclick="openPop(<?=$site['siteID']?>,'<?=$site['siteName']?>')"><?=outDb($site['phone'])?></td>
                <td onclick="openPop(<?=$site['siteID']?>,'<?=$site['siteName']?>')"><?=outDb($site['email'])?></td>
                <td><?=($site['active']?"<span style='color:green;'>כן</span>":"<span style='color:red;'>לא</span>")?></td>
            </tr>
<?php
			}
			}
?>
        </tbody>
    </table>
</div>
<input type="hidden" id="orderResult" name="orderResult" value="">
<script>
var pageType="<?=$pageType?>";
function openPop(pageID, siteName){
	$(".pagePopCont").html('<iframe id="frame_'+pageID+'" frameborder=0 src="/cms/moduls/minisites/frame.dor.php?siteID='+pageID+'&siteName='+siteName+'&tab=1"></iframe><div class="tabCloser" onclick="closeTab(\'frame_'+pageID+'\')">x</div>');
	$(".pagePop").show();
}
function closeTab(){
	$(".pagePopCont").html('');
	$(".pagePop").hide();
}

/*
function orderNow(is){
	$("#addNewAcc").hide();
	$(is).val("שמור סדר תצוגה");
	$(is).attr("onclick", "saveOrder()");
	$("#sortRow tr").attr("onclick", "");
	$("#sortRow").sortable({
		stop: function(){
			$("#orderResult").val($("#sortRow").sortable('toArray'));
		}
	});
	$("#orderResult").val($("#sortRow").sortable('toArray'));
}
function saveOrder(){
	var ids = $("#orderResult").val();
	$.ajax({
		url: 'js_order_pages.php',
		type: 'POST',
		data: {ids:ids, type:pageType},
		async: false,
		success: function (myData) {
			window.location.reload();
		}
	});
}
*/
</script>
<?php



include_once "../../bin/footer.php";
?>
