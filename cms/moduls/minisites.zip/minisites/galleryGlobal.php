<?php

include_once "../../bin/system.php";
include_once "../../bin/top_frame.php";
include_once "../../_globalFunction.php";


//$domainID = intval($_GET['domainID']);
$siteID = intval($_GET['siteID']);
$galleryID = intval($_GET['gID']);
$roomID = intval($_GET['roomID']);
//$siteName = intval($_GET['siteName']);


$domainID = DomainList::active();
$langID   = LangList::active();


if ('POST' == $_SERVER['REQUEST_METHOD']){

//	print_R($_POST);exit;

	try {
     $data = typemap($_POST, [
		'galleryTitle'   => 'string',
		'!gallerySummer'   => 'int',
		'!galleryWinter'   => 'int',
		'imTitle'  => ['int' => ['int' => 'string']],
		'imDesc'   => ['int' => ['int' => 'string']],
		'imLink'   => ['int' => ['int' => 'string']],
		'imID'     => ['int']

	]);


        if (!$data['galleryTitle'])
            throw new LocalException('נא להכניס שם לגלריה');

	
		if(count($_POST['orderResult']))
		{
			$ids = str_replace("imageBoxList_","",$_POST['orderResult']);
			$ids = explode(",",$ids);
			if($ids)
			{
				foreach($ids as $key=>$id)
				{
					if($id)
					{
						$query=Array();
						$query['showOrder']=$key;
						udb::update("pictures", $query, "galleryID='".$galleryID."' AND  fileID=".$id);
					}
				}	
			}
		}
		if($data['imID']){
			foreach($data['imID'] as $picID){
			// saving data per domain / language
				foreach(LangList::get() as $lid => $lang){
					// inserting/updating data in domains table
					udb::insert('pictures_text', [
						'pictureID'    => $picID,
						'langID'    => $lid,
						'galleryID'    => $galleryID,
						'pictureTitle'  => $data['imTitle'][$picID][$lid],
						'pictureDesc'   => $data['imDesc'][$picID][$lid],
						'pictureLink'   => $data['imLink'][$picID][$lid]
					], true);
				}
			}
		}
	

		if($galleryID){
			if($_POST['img']){
				foreach($_POST['img'] as $pos){
					$picData['galleryID'] = $galleryID;
					$picData['fileID'] = $pos;
					udb::insert('pictures', $picData,true);
					//save langs
				}
			 }

			if($siteID){
			
				$data['gallerySummer']==1?$galData['gallerySummer'] = $galleryID:0;
			    $data['galleryWinter']==1?$galData['galleryWinter'] = $galleryID:0;
				udb::update('sites', $galData, '`siteID` = ' . $siteID);
			}
			if($roomID){
				$data['gallerySummer']==1?$galData['gallerySummer'] = $galleryID:0;
			    $data['galleryWinter']==1?$galData['galleryWinter'] = $galleryID:0;
				udb::update('rooms', $galData, '`roomID` = ' . $roomID);
			}

		}
		else{
			 $siteData = [
				'siteID'  => $siteID,
				'domainID'  => $domainID,
				'galleryTitle'	 => $data['galleryTitle']
			];
			 $gallID = udb::insert('galleries', $siteData);
			

			 if($roomID){
				 udb::insert('rooms_galleries', ['roomID'  => $roomID,'galleryID' =>  $gallID]);
				 $galData['galleryID']=$gallID;
				 udb::update('rooms', $galData, '`roomID` = ' . $roomID);
			 }else{
				 udb::insert('sites_galleries', ['siteID'  => $siteID,'galleryID' =>  $gallID]);
				 $galData['galleryID']=$gallID;
				 udb::update('sites', $galData, '`siteID` = ' . $siteID);
			 
			 }

			 foreach($_POST['img'] as $pos){
				$picData['galleryID'] = $gallID;
				$picData['fileID'] = $pos;
				udb::insert('pictures', $picData);
			 }
			
		}

	
}
    catch (LocalException $e){
        // show error
    } ?>
<script>window.parent.location.reload(); window.parent.closeTab();</script>
<?php }


$que = "SELECT `folderID`,folderTitle FROM `folder` WHERE siteID=".$siteID;
$folders = udb::key_row($que,"folderID");

$galleryFolderName = udb::single_value("SELECT `galleryTitle` FROM `galleries` WHERE galleryID=".$galleryID);
if($galleryID){
	$picList = udb::key_row("SELECT `files`.`src`, `pictures`.`fileID`, `pictures`.`pictureID`, `pictures`.`showOrder` 
	FROM `pictures` 
	INNER JOIN `files` ON `pictures`.`fileID`= `files`.`id`
	WHERE galleryID=".$galleryID." ORDER BY `showOrder`","fileID");
	$picLangs   = udb::key_row("SELECT * FROM `pictures_text` WHERE `galleryID` = " . $galleryID, ['pictureID','langID']);

	if($siteID){
		$galType = udb::single_row("SELECT galleryWinter,gallerySummer FROM `sites` WHERE siteID=".$siteID);
	}
	if($roomID){
		$galType = udb::single_row("SELECT galleryWinter,gallerySummer FROM `rooms` WHERE roomID=".$roomID);
	}

} ?>

<div class="editItems">
	<form method="post" enctype="multipart/form-data" >
		<div class="inputLblWrap langsdom">
			<div class="labelTo">דומיין</div>
			<?=DomainList::html_select()?>
		</div>
		<div class="inputLblWrap langsdom">
			<div class="labelTo">שפה</div>
			<?=LangList::html_select()?>
		</div>
		<div class="galName">
			<div class="inputLblWrap">
				<div class="labelTo">שם הגלריה</div>
				<input type="text" placeholder="שם הגלריה" name="galleryTitle" value="<?=$galleryFolderName?>" />
			</div>
			<div class="inputLblWrap">
				<div class="labelTo">סוג גלריה</div>
				<div class="checkLabel checkIb">
					<div class="checkBoxWrap">
						<input class="checkBoxGr" type="checkbox" name="galleryWinter" value="1" id="ch1" <?=$galType['galleryWinter']==$galleryID && $galleryID!=0?" checked":""?>>
						<label for="ch1"></label>
					</div>
					<label for="ch1">גלרית חורף</label>
				</div>
				<div class="checkLabel checkIb">
					<div class="checkBoxWrap">
						<input class="checkBoxGr" type="checkbox" name="gallerySummer" value="1" id="ch2" <?=$galType['gallerySummer']==$galleryID && $galleryID!=0?" checked":""?>>
						<label for="ch2"></label>
					</div>
					<label for="ch2">גלרית קיץ</label>
				</div>
		
			</div>
		</div>


		<div class="imagesWrapSelected imagWrap">
			<?php 
			if($picList) { ?>
				<div class="frameTtl">תמונות שנבחרו</div>
				<div class="sortBtn" onclick="startGalOrder(this)">סדר תמונות</div>
				<div class="sortBtn showDescBtn">הצג/הסתר תיאור</div>
			<?php } ?>
			<div class="imgGalFrWrap">
			<?php 
			if($picList) {
			$ids="";
			$i=0;
			foreach($picList as $pic){ 
				$ids.=($i!=0?",":"")."imageBoxList_".$pic['fileID']; ?>
				<div class="imgGalFr chos" id="imageBoxList_<?=$pic['fileID']?>">
					<div class="delPic" onclick="delPic(<?=$pic['pictureID']?>,'imageBoxList_<?=$pic['fileID']?>')"><i class="fa fa-trash-o" aria-hidden="true"></i></div>
					<div class="pic"><a href="<?=$pic['src']?>" data-lightbox="image-1" data-title="<?=htmlentities(stripslashes($pic['title']))?>"><img src="<?=$pic['src']?>"></a></div>
					<input type="hidden" name="imID[]" value="<?=$pic['pictureID']?>">
					<?php foreach(LangList::get() as $id => $lang){ ?>
					<div class="language" data-id="<?=$id?>">
						<div class="ttlWrap">
						   <div class="ttl"><input type="text" name="imTitle[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureTitle']))?>" placeholder="כותרת"></div>
						  <div class="ttl"><input type="text" name="imDesc[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureDesc']))?>" placeholder="תיאור"></div>
						  <div class="ttl"><input type="text" name="imLink[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureLink']))?>" placeholder="קישור"></div>
						</div>
					</div>
					<?php } ?>
				</div>
			<?php $i++;  } } ?>	
			</div>
			<input type="hidden" id="orderResult" name="orderResult" value="<?=$ids?>">
		</div>
		<?php if($folders){ ?>
			<div class="imagWrap">
				<div class="frameTtl">בחירת תמונות מבנק תמונות</div>
				<?php 
				$ids="";
				$i=0;
				foreach($folders as $fold){ 
					$pictureFold = udb::full_list("SELECT * FROM `files` WHERE ref=".$fold['folderID']); ?>

					<div class="galTitle"><?=$fold['folderTitle']?></div>
					<?php foreach($pictureFold as $image) {
					
					if(!$picList[$image['id']]['fileID']==$image['id']) {
					$ids.=($i!=0?",":"")."imageBox_".$image['id']; ?>
					<div class="imgGalFr" id="imageBox_<?=$image['id']?>">
						<label for="imgcheck<?=$image['id']?>">סמן</label>
						<input <?=($picList[$image['id']]['fileID']==$image['id']?"checked":"")?>  class="choosePic" value="<?=$image['id']?>" type="checkbox" name="img[]" id="imgcheck<?=$image['id']?>">
						<div class="pic"><a href="<?=$image['src']?>" data-lightbox="image-1" data-title="<?=htmlentities(stripslashes($image['title']))?>"><img src="<?=$image['src']?>"></a></div>
					</div>
				<?php $i++; } } } ?>	
			</div>
			<!-- <div class="addPicBtnWrap">
				<input class="addPicBtn" type="submit" value="הוסף תמונות נבחרות">
			</div> -->
		<?php } ?>

		
		<div class="addPicBtnWrap">
			<input type="submit" name="saveOrder" value="שמור" class="addPicBtn">	
		</div>
	</form>
</div>



<script type="text/javascript">


	function startGalOrder(is){
	//	$(".uploadLabel").hide();
	//	$(".imgGalFr input").attr("disabled", "disabled");
		$(".delPic").hide();
		$(".sortBtn.showDescBtn").hide();
		$(is).hide();
		$(".imgGalFr.chos").css({'box-shadow':'0 0 16px 0px rgba(0,0,0,0.8)','cursor':'pointer'});
		$(".imgGalFrWrap").sortable({
			stop: function(){
				$("#orderResult").val($(".imgGalFrWrap").sortable('toArray'));
			}
		});
		$("#orderResult").val($(".imgGalFrWrap").sortable('toArray'));
	}
		$('.showDescBtn').click(function(){
				$('.ttlWrap').toggleClass("show");
		});


	function delPic(id,removeElemnt){
		if(confirm("האם אתה מעוניין למחוק תמונה זו?")){
			$.post("ajax_del_picture.php",{picID:id}).done(function(){
				window.location.reload();
			});
		
		}
	}

	$(function(){
		$.each({domain: <?=$domainID?>, language: <?=$langID?>}, function(cl, v){
			$('.' + cl).hide().each(function(){
				var id = $(this).data('id');
				$(this).find('input, select, textarea').each(function(){
					this.name = this.name + '[' + id + ']';
				});
			}).filter('[data-id="' + v + '"]').show();

			$('.' + cl + 'Selector').on('change', function(){
				$('.' + cl, $(this).data('cont')).hide().filter('[data-id="' + this.value + '"]').show();
			});
		});


	});
</script>