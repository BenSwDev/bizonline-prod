<?php

include_once "../../bin/system.php";
include_once "../../bin/top_frame.php";
include_once "../../_globalFunction.php";


//$domainID = intval($_GET['domainID']);
$siteID = intval($_GET['siteID']);
$galleryID = intval($_GET['gID']);
$roomID = intval($_GET['roomID']);
//$siteName = intval($_GET['siteName']);


$domainID = DomainList::active();
$langID   = LangList::active();


if ('POST' == $_SERVER['REQUEST_METHOD']){

	try {
     $data = typemap($_POST, [
		'galleryTitle'   => 'string',
		'imTitle'  => ['int' => ['int' => 'string']],
		'imDesc'   => ['int' => ['int' => 'string']],
		'imLink'   => ['int' => ['int' => 'string']],
		'imID'     => ['int']
	]);

	if($_POST['saveOrder']){
		if(isset($_POST['orderResult'])){
			$ids = str_replace("imageBoxList_","",$_POST['orderResult']);
			$ids = explode(",",$ids);
			if($ids){
				foreach($ids as $key=>$id){
					if($id){
						$query=Array();
						$query['showOrder']=$key;
						udb::update("pictures", $query, "galleryID='".$galleryID."' AND  fileID=".$id);
					}
				}
				
			}
		}
		foreach($data['imID'] as $picID){
		// saving data per domain / language
			foreach(LangList::get() as $lid => $lang){
				// inserting/updating data in domains table
				udb::insert('pictures_langs', [
					'pictureID'    => $picID,
					'langID'    => $lid,
					'galleryID'    => $galleryID,
					'pictureTitle'  => $data['imTitle'][$picID][$lid],
					'pictureDesc'   => $data['imDesc'][$picID][$lid],
					'pictureLink'   => $data['imLink'][$picID][$lid]
				], true);
			}
		}

	}
	else
		{
		if($galleryID){
			 foreach($_POST['img'] as $pos){
				$picData['galleryID'] = $galleryID;
				$picData['fileID'] = $pos;
				udb::insert('pictures', $picData,true);
				//save langs
			 }
		}
		else{
			 $siteData = [
				'siteID'  => $siteID,
				'domainID'  => $domainID,
				'galleryTitle'	 => $data['galleryTitle']
			];
			 $gallID = udb::insert('galleries', $siteData);


			 if($roomID){
				 $galData['galleryID']=$gallID;
				 udb::update('rooms', $galData, '`roomID` = ' . $roomID);
			 }else{

				 $galData['galleryID']=$gallID;
				 udb::update('sites', $galData, '`siteID` = ' . $siteID);
			 
			 }

			 foreach($_POST['img'] as $pos){
				$picData['galleryID'] = $gallID;
				$picData['fileID'] = $pos;
				udb::insert('pictures', $picData);
			 }
			
		}

	}
}
    catch (LocalException $e){
        // show error
    } 
} 


$galleryName = udb::single_value("SELECT `galleryTitle` FROM `galleries` WHERE galleryID=".$galleryID);

/*$que = "SELECT `folder`.`folderID`,`files`.`id`, `files`.`src` 
		FROM `folder` 
		INNER JOIN `files` ON `folder`.folderID = `files`.`ref`
		WHERE `folder`.`siteID`=".$siteID;*/

$que = "SELECT `folderID`,folderTitle FROM `folder` WHERE siteID=".$siteID;
$folders = udb::key_row($que,"folderID");
ד

if($galleryID){
	$picList = udb::key_row("SELECT `fileID`,`pictureID`,`showOrder` FROM `pictures` WHERE galleryID=".$galleryID." ORDER BY `showOrder`","fileID");
	$picLangs   = udb::key_row("SELECT * FROM `pictures_langs` WHERE `galleryID` = " . $galleryID, ['pictureID','langID']);
}



?>

<div class="editItems">
	<form method="post" enctype="multipart/form-data" >
		<div class="inputLblWrap langsdom">
			<div class="labelTo">דומיין</div>
			<?=DomainList::html_select()?>
		</div>
		<div class="inputLblWrap langsdom">
			<div class="labelTo">שפה</div>
			<?=LangList::html_select()?>
		</div>
		<div class="galName">
			<div class="inputLblWrap">
				<div class="labelTo">שם הגלריה</div>
				<input type="text" placeholder="שם הגלריה" name="galleryTitle" value="<?=$galleryName?>" <?=($galleryName)?"disabled":""?> />
			</div>
		</div>
		<?php if($pictures){ ?>
		<div class="imagWrap">
			<div class="frameTtl">בחירת תמונות מבנק תמונות</div>
			<?php 
			$ids="";
			$i=0;
			foreach($pictures as $image){ 
				if(!$picList[$image['id']]['fileID']==$image['id']) {
				$ids.=($i!=0?",":"")."imageBox_".$image['id']; ?>
				<div class="imgGalFr" id="imageBox_<?=$image['id']?>">
					<label for="imgcheck<?=$image['id']?>">סמן</label>
					<input <?=($picList[$image['id']]['fileID']==$image['id']?"checked":"")?>  class="choosePic" value="<?=$image['id']?>" type="checkbox" name="img[]" id="imgcheck<?=$image['id']?>">
					<div class="pic"><a href="../../../gallery/<?=$image['src']?>" data-lightbox="image-1" data-title="<?=htmlentities(stripslashes($image['title']))?>"><img src="../../../gallery/<?=$image['src']?>"></a></div>
				</div>
			<?php $i++; } } ?>	
		</div>
		<div class="addPicBtnWrap">
			<input class="addPicBtn" type="submit" value="הוסף תמונות נבחרות">
		</div>
		<?php } ?>
		<div class="imagesWrapSelected imagWrap">
			<?php 
			if($picList) { ?>
				<div class="frameTtl">תמונות שנבחרו</div>
				<div class="sortBtn" onclick="startGalOrder(this)">סדר תמונות</div>
				<div class="sortBtn showDescBtn">הצג/הסתר תיאור</div>
			<?php } ?>
			<div class="imgGalFrWrap">
			<?php 
			if($picList) {
			$ids="";
			$i=0;
			foreach($picList as $pic){ 
				$ids.=($i!=0?",":"")."imageBoxList_".$pic['fileID']; ?>
				<div class="imgGalFr chos" id="imageBoxList_<?=$pic['fileID']?>">
					<div class="delPic" onclick="delPic(<?=$pic['pictureID']?>,'imageBoxList_<?=$pic['fileID']?>')"><i class="fa fa-trash-o" aria-hidden="true"></i></div>
					<div class="pic"><a href="../../../gallery/<?=$pictures[$pic['fileID']]['src']?>" data-lightbox="image-1" data-title="<?=htmlentities(stripslashes($pic['title']))?>"><img src="../../../gallery/<?=$pictures[$pic['fileID']]['src']?>"></a></div>
					<input type="hidden" name="imID[]" value="<?=$pic['pictureID']?>">
					<?php foreach(LangList::get() as $id => $lang){ ?>
					<div class="language" data-id="<?=$id?>">
						<div class="ttlWrap">
						   <div class="ttl"><input type="text" name="imTitle[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureTitle']))?>"	placeholder="כותרת"></div>
						  <div class="ttl"><input type="text" name="imDesc[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureDesc']))?>" placeholder="תיאור"></div>
						  <div class="ttl"><input type="text" name="imLink[<?=$pic['pictureID']?>]" value="<?=htmlentities(stripslashes($picLangs[$pic['pictureID']][$id]['pictureLink']))?>" placeholder="קישור"></div>
						</div>
					</div>
					<?php } ?>
				</div>
			<?php $i++;  } } ?>	
			</div>
		</div>
		<input type="hidden" id="orderResult" name="orderResult" value="<?=$ids?>">
		<div class="addPicBtnWrap">
			<input type="submit" name="saveOrder" value="שמור" class="addPicBtn">	
		</div>
	</form>
</div>



<script type="text/javascript">


	function startGalOrder(is){
	//	$(".uploadLabel").hide();
	//	$(".imgGalFr input").attr("disabled", "disabled");
		$(".delPic").hide();
		$(".sortBtn.showDescBtn").hide();
		$(is).hide();
		$(".imgGalFr.chos").css({'box-shadow':'0 0 16px 0px rgba(0,0,0,0.8)','cursor':'pointer'});
		$(".imgGalFrWrap").sortable({
			stop: function(){
				$("#orderResult").val($(".imgGalFrWrap").sortable('toArray'));
			}
		});
		$("#orderResult").val($(".imgGalFrWrap").sortable('toArray'));
	}
		$('.showDescBtn').click(function(){
				$('.ttlWrap').toggleClass("show");
		});


	function delPic(id,removeElemnt){
		if(confirm("האם אתה מעוניין למחוק תמונה זו?")){
			$.post("ajax_del_picture.php",{picID:id}).done(function(){
				window.location.reload();
			});
		
		}
	}

	$(function(){
		$.each({domain: <?=$domainID?>, language: <?=$langID?>}, function(cl, v){
			$('.' + cl).hide().each(function(){
				var id = $(this).data('id');
				$(this).find('input, select, textarea').each(function(){
					this.name = this.name + '[' + id + ']';
				});
			}).filter('[data-id="' + v + '"]').show();

			$('.' + cl + 'Selector').on('change', function(){
				$('.' + cl, $(this).data('cont')).hide().filter('[data-id="' + this.value + '"]').show();
			});
		});


	});
</script>